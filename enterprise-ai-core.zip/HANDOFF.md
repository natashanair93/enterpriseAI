# Enterprise AI Core: handoff

This folder is a brand-agnostic design system for enterprise AI products (document extraction and review, workflows and approvals, copilot chat, data and dashboards).

Start by reading, in order:
1. `project/README.md`: principles, content rules, visual foundations
2. `project/brand-layer.md`: how a client brand is applied on top
3. `project/patterns.md`: layouts and patterns, and when to use each
4. `project/tokens.json`: all tokens (primitives, then roles; themes `neutral` and `high-contrast`)
5. `project/components/<Name>/README.md`: guidelines per component

How it's built:
- Components use role tokens only, never primitives or hex values. A brand layer changes only primitives, font families and radii.
- `project/components/bundle.js` is a single classic script that sets `window.EAI` (React 18 global, no build step). `bundle.css` holds the styles. `index.d.ts` documents the props.
- Each `components/<Name>/preview.html` renders one component. It expects tokens compiled to CSS custom properties (`--<token-name>`, fonts as `--font-display`, `--font-ui`, `--font-mono`), plus bundle.css, React and bundle.js already loaded.
- The original lives as a Claude "Design System" artifact. To continue there, upload these files into a new Design System artifact, keeping the `project/` paths.

Keep when extending: show sources for AI output, mark AI with AILabel, human approval for consequential actions, an audit trail, honest states (stopped ≠ failed), WCAG AA in neutral and AAA text in high-contrast.
