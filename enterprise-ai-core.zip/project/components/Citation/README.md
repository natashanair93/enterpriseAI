# Citation

Numbered source pill placed inline after an AI claim. It links to the exact source location.

**Provide** `n`, `label` (source name + locator, read as the accessible name), optional `active`, `onClick`.

- Cite only sources actually used. Clicking opens the source at the location (page, row, cell) with the passage highlighted.
- One citation per claim. Several numbers in a row mean the claim needs splitting.
