# CompareView

Side-by-side comparison of two to four things on the same fields: this quarter vs last, two document versions, extracted value vs system of record, two model outputs, vendor proposals. The first column is the baseline. Changed cells are tinted and bold, numeric rows show % change against the baseline, and a toggle hides identical rows.

**Provide** `items` (`{ title, subtitle?, badge? }[]`), `rows` (`{ label, values: [], numeric? }[]`), optional `summary` (an AI summary of what changed, shown with the AI tone), `baselineLabel` (or `false`), `onlyDifferences`, `selectable` + `selectLabel` (pick one version).

- Keep rows aligned across columns; never compare things laid out differently. Units must match.
- The AI summary states the material differences in a sentence or two and cites them. The table stays the evidence.
- Up to 4 columns; beyond that, scroll horizontally with the label column fixed.
- For text (clauses, notes), show a redline inside the cell rather than two blocks of prose.
