# Icon

Outline icon set used by every component: 24px grid, 1.75px stroke, drawn in `currentColor` at 16–20px.

**Provide** `name`, optional `size`, and `label` only when the icon stands alone and carries meaning (otherwise it is hidden from assistive tech).

- Icons inherit the color of the text beside them; never color an icon independently except status icons (`success`, `warning`, `error`, `info`) and the AI sparkle (`ai`).
- Outline only — no filled, duotone or emoji substitutes. A brand layer may swap in the client's own icon set as long as it is outline, 24px, and keeps these names.
- `sparkle` is reserved for AI presence. Don't use it as decoration or for non-AI features.
