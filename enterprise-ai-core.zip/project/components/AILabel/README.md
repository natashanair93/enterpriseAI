# AILabel

Marks AI-generated content and opens a short explanation on click. It's the single, consistent signal for "a model produced this".

**Provide** optional `title`, `summary` (one or two sentences: what the AI did, and what to check), `details` (`{k, v}[]`, e.g. model, source, confidence threshold), `inline` for the compact size next to text, `text` to localize "AI".

- Put it on any AI-generated value, field, summary, or chat reply. Containers: top-right. Inputs: inside the label row. Tables: in the column header when a whole column is generated, inline in the cell when only some cells are.
- It explains; it never triggers actions. Regenerate, accept and edit get their own buttons.
- Once a person edits the value, remove the label (the value is now theirs) and record the change in the `AuditTrail`.
- Explanations start short. Put detail behind "View details" rather than in the popover.
