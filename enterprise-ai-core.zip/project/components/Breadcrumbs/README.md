# Breadcrumbs

Where the user is in a hierarchy: Portfolio › Northwind Holdings › Q3 valuation.

**Provide** `items` (labels, last = current page).

- Use when pages are more than two levels deep. On detail pages it replaces a bare back link.
