# InlineAlert

In-page message in a tinted box: info, success, warning, error, or AI.

**Provide** `tone`, `children`, optional `title` and `actions` (buttons).

- Errors say what failed, why, and what to do next; offer at least one action.
- The `ai` tone is for AI notices ("6 fields need review before this can be approved"), not for errors.
- Persistent; for transient confirmations use `Toast`.
