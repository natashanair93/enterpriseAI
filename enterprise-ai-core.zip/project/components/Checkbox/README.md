# Checkbox

Checkbox with a label to its right. Use for independent choices and confirmations.

**Provide** `children` (label), optional `checked`, `disabled`.

- For "I've reviewed this" style attestations before approval, make the label specific: "I've checked all 6 flagged fields against the source".
