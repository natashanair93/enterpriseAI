# Tabs

Switch between sections of the same object: Overview / Fields / History. The active tab is marked by weight and an accent underline.

**Provide** `tabs` (strings or `{label, count}`), optional `active` + `onChange`.

- Counts flag work ("Fields 6"). On narrow screens tabs scroll horizontally.
