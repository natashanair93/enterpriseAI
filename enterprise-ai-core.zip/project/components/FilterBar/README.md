# FilterBar

Row of filter pills above a table or list. Active filters show their value and can be cleared.

**Provide** `filters` (`{ label, value?, active? }[]`), optional `onClear`.

- Put the most-used filter first. "Needs review" is usually it.
