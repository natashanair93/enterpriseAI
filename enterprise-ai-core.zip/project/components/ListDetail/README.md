# ListDetail

List with a detail flyout. Clicking a row opens its details in a right-side flyout **in the same view**, so the user keeps the list, filters and scroll position. The selected row is marked; previous / next step through items; Esc or ✕ closes; a maximize button opens the full page.

**Provide** `items` (each with an `id`), `columns` (`DataTable` column shape), `renderDetail(item)`, optional `renderFooter(item)` (actions), `toolbar` (`FilterBar`, search), `overline`, `titleKey`, `subtitleKey`, `defaultSelected`, `height`.

- Use the flyout for "look, decide, move on" (review queues, documents, records). Use a full page when the detail has its own tabs, long forms, or is shared by link.
- On wide screens the flyout pushes the list; under 900px it overlays it. It never covers the row it belongs to without the list staying scrollable.
- Keyboard: Enter opens, Esc closes, and focus returns to the row on close.
