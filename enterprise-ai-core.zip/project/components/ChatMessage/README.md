# ChatMessage

A turn in the conversation. User turns are accent bubbles on the right. Assistant turns are plain text on the left, with an AI label, optional meta, and copy / feedback / regenerate actions. System turns are small and centered ("Switched to Contoso term sheet").

**Provide** `role` (`user` | `assistant` | `system`), `children`, optional `meta`, `disclosure`, `feedback` (false to hide actions).

- Lead with the answer. No greetings, no "Great question", no sign-offs.
- Feedback buttons are neutral (Helpful / Not helpful). Never ask for feedback in prose.
