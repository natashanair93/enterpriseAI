# DataTable

Table for documents, fields, runs and records: sticky header, comfortable rows, right-aligned numbers, optional row selection, and built-in status / confidence / mono cell kinds.

**Provide** `columns` (`{ key, label, align?: 'right', kind?: 'status' | 'confidence' | 'mono' }[]`), `rows`, optional `selectable`, `caption`.

- First column is the object's name, in bold. Numbers right-aligned with tabular figures and consistent units.
- Row height comes from `row-height`. Data-heavy projects may lower it in their layer, but never below 40px.
- Wide tables scroll inside their container, never the page. Bulk actions appear above the table once rows are selected.
