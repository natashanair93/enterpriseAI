# ThinkingIndicator

Live progress label while the assistant works. It names the actual step and object, and replaces itself in place.

**Provide** `children` ("Reading page 12 of `Valuation_Report_Q3.pdf`"), optional `onStop`.

- Name the real step. Never "Thinking…" or "Almost there". No percentages unless the system reports them.
- Long work offers Stop.
