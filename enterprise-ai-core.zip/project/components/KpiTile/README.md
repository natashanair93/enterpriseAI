# KpiTile

Headline number with a label and a delta that names its comparison.

**Provide** `label`, `value`, optional `delta`, `trend` (`up` | `down` | `flat`), `comparison` ("vs last quarter").

- `up` is green and `down` is red by default. If down is good (cost, review time), pass the trend that matches the meaning, not the direction.
- Always name the baseline. A bare arrow is not information.
