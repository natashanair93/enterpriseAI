# Modal

Blocking dialog for a decision that has to be made now. The title is a question, the body states the consequence, and the confirm button uses the consequence's verb.

**Provide** `title`, `children`, `confirmLabel`, optional `destructive`, `cancelLabel`, `onConfirm`, `onCancel`.

- Use only for destructive, irreversible or high-stakes steps. Everything else belongs inline or in a `Drawer`.
- Cancel is always present and always safe.
