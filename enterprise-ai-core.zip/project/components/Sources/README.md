# Sources

Numbered list of sources under an answer, matching its inline `Citation`s: name, locator, and as-of time.

**Provide** `sources` (`{ label, locator?, asOf? }[]`, max ~5).

- Only sources actually opened. Add `asOf` to anything that changes (systems of record, live data).
