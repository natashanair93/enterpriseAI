# KeyValueList

Label/value pairs in two columns: gray keys, strong values, mono for IDs.

**Provide** `items`: `{ key, value, mono? }[]`. Values can be nodes (a badge, a link, a `ConfidenceIndicator`).

- Keys are sentence case and short. Right-align nothing here; numbers line up through tabular figures.
