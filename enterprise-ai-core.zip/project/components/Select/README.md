# Select

Native select with the field styling: label, helper, error, AI-prefilled.

**Provide** `label`, `options`, optional `value`, `help`, `error`, `aiFilled`.

- Use for 4–15 options. Fewer: `SegmentedControl` or radio. More: a searchable combobox in the product layer.
