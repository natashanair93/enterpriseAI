# Panel

Titled section container with a header row (title, icon, actions) and a body. Holds key-value lists, tables, charts and forms on detail pages.

**Provide** `title`, optional `icon`, `actions`, `flush` (no body padding, for tables), `children`.

- Panels sit on `surface-page`, and several panels make a page. Don't nest panels inside panels; use headings instead.
