# WorkspaceLayout

Three-pane workspace: **left** for inputs (sources, documents, navigation in a record), **center** for the work (the document, the analysis, the draft), **right** for help (the assistant, insights, history). This is the NotebookLM shape (Sources / Chat / Studio) and the shape most document-centred AI tools converge on.

**Provide** `center`, plus any of `left` / `right` with `leftTitle` / `rightTitle`, `leftIcon` / `rightIcon`, `leftActions` / `rightActions`, `leftCollapsed` / `rightCollapsed`, optional `header` (an `AppHeader`), `centerTitle`, `centerActions`, `height`.

- Each side pane collapses to a 52px rail with its icon and name, so the center can take the room. The center never collapses.
- Default widths: left 240–300px, right `panel-width` (420px), center fluid. Under 1100px both side panes become rails and open as overlays. Under 760px, show one pane at a time behind tabs (product layer).
- What's selected on the left scopes the right ("Using 3 of 5 sources"). Citations in the right pane open their source in the center.
- Remember each user's collapsed and open state per product.
