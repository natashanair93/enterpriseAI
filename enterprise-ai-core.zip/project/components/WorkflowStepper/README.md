# WorkflowStepper

The stages of a business workflow, end to end, for example Upload › Extract › Validate › Review › Approve › Export. Each stage shows its state.

**Provide** `steps` (`{ label, state: 'done' | 'current' | 'attention' | 'failed' | 'upcoming', detail? }[]`), optional `label`.

- `attention` means the workflow is waiting on a person ("Review: 6 fields"). Put the count in `detail`.
- Stages are business steps the user recognizes, not system internals. Run internals go in `StepList`.
