# CopilotPanel

Right-side assistant scoped to what the user is looking at: header, a "Using: <context>" line, the thread, suggestions, composer, and a standing disclaimer.

**Provide** optional `title`, `context` (the document or record in scope), `suggestions`, `placeholder`, `note`, `onClose`, and `children` (the thread: `ChatMessage`, cards, `ThinkingIndicator`).

- Docked at `panel-width` beside the main view; never covers the content it's talking about. It opens with context already attached.
- Starter suggestions use the user's real objects ("Why are 6 fields flagged?"), with no greeting.
- Answers about documents cite sources. Actions with side effects go through `PlanCard` / `ConfirmCard`.
