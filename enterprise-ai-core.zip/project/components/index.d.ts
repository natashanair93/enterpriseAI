// Enterprise AI Core — component props (documentation). Global: window.EAI
import * as React from 'react';
export declare function Highlight(props: { active?: boolean; children: React.ReactNode }): React.ReactElement;
export interface IconProps { name: string; size?: number; label?: string; className?: string }
export declare function Icon(props: IconProps): React.ReactElement;
export interface AILabelProps { title?: string; summary?: string; details?: { k: string; v: string }[]; inline?: boolean; text?: string; open?: boolean }
export declare function AILabel(props: AILabelProps): React.ReactElement;
export interface ButtonProps { variant?: 'primary' | 'secondary' | 'tertiary' | 'danger'; size?: 'sm' | 'md' | 'lg'; icon?: string; trailingIcon?: string; disabled?: boolean; onClick?: () => void; children: React.ReactNode }
export declare function Button(props: ButtonProps): React.ReactElement;
export interface IconButtonProps { icon: string; label: string; size?: 'sm'; pressed?: boolean; disabled?: boolean; onClick?: () => void }
export declare function IconButton(props: IconButtonProps): React.ReactElement;
export interface SegmentedControlProps { options: string[]; value?: string; onChange?: (v: string) => void; label?: string }
export declare function SegmentedControl(props: SegmentedControlProps): React.ReactElement;
export interface ToggleProps { checked?: boolean; onChange?: (on: boolean) => void; label?: string; children?: React.ReactNode }
export declare function Toggle(props: ToggleProps): React.ReactElement;
export interface TextFieldProps { label: string; value?: string; placeholder?: string; help?: string; error?: string; required?: boolean; type?: string; disabled?: boolean; aiFilled?: boolean; aiNote?: string }
export declare function TextField(props: TextFieldProps): React.ReactElement;
export interface SelectProps { label: string; options: string[]; value?: string; help?: string; error?: string; aiFilled?: boolean }
export declare function Select(props: SelectProps): React.ReactElement;
export interface CheckboxProps { children: React.ReactNode; checked?: boolean; disabled?: boolean }
export declare function Checkbox(props: CheckboxProps): React.ReactElement;
export interface StatusBadgeProps { status: 'complete' | 'approved' | 'passed' | 'review' | 'pending' | 'draft' | 'failed' | 'rejected' | 'running' | 'queued' | 'stopped' | 'archived' | 'ai'; children?: React.ReactNode }
export declare function StatusBadge(props: StatusBadgeProps): React.ReactElement;
export interface TagProps { children: React.ReactNode; onRemove?: () => void }
export declare function Tag(props: TagProps): React.ReactElement;
export interface ConfidenceIndicatorProps { value: number | null; thresholds?: { high?: number; review?: number }; level?: 'high' | 'medium' | 'low'; showValue?: boolean }
export declare function ConfidenceIndicator(props: ConfidenceIndicatorProps): React.ReactElement;
export interface InlineAlertProps { tone?: 'info' | 'success' | 'warning' | 'error' | 'ai'; title?: string; children: React.ReactNode; actions?: React.ReactNode }
export declare function InlineAlert(props: InlineAlertProps): React.ReactElement;
export interface ToastProps { children: React.ReactNode; tone?: 'info' | 'success' | 'warning' | 'error'; action?: React.ReactNode; onClose?: () => void }
export declare function Toast(props: ToastProps): React.ReactElement;
export interface ProgressBarProps { label?: string; value?: number; detail?: string }
export declare function ProgressBar(props: ProgressBarProps): React.ReactElement;
export interface AppHeaderProps { company?: string; product?: string; logoSrc?: string; initials?: string; children?: React.ReactNode }
export declare function AppHeader(props: AppHeaderProps): React.ReactElement;
export interface SideNavProps { sections: { title?: string; items: { label: string; icon?: string; count?: number }[] }[]; active?: string; onNavigate?: (label: string) => void; label?: string }
export declare function SideNav(props: SideNavProps): React.ReactElement;
export interface TabsProps { tabs: (string | { label: string; count?: number })[]; active?: string; onChange?: (label: string) => void }
export declare function Tabs(props: TabsProps): React.ReactElement;
export interface BreadcrumbsProps { items: string[] }
export declare function Breadcrumbs(props: BreadcrumbsProps): React.ReactElement;
export interface CardProps { overline?: string; title?: string; description?: string; status?: React.ReactNode; footer?: React.ReactNode; children?: React.ReactNode; onClick?: () => void }
export declare function Card(props: CardProps): React.ReactElement;
export interface PanelProps { title?: string; icon?: string; actions?: React.ReactNode; flush?: boolean; children?: React.ReactNode }
export declare function Panel(props: PanelProps): React.ReactElement;
export interface KeyValueListProps { items: { key: string; value: React.ReactNode; mono?: boolean }[] }
export declare function KeyValueList(props: KeyValueListProps): React.ReactElement;
export interface EmptyStateProps { title: string; text?: string; icon?: string; action?: string; actionIcon?: string; secondary?: string }
export declare function EmptyState(props: EmptyStateProps): React.ReactElement;
export interface DrawerProps { title: string; overline?: string; subtitle?: string; footer?: React.ReactNode; fixed?: boolean; onClose?: () => void; children?: React.ReactNode }
export declare function Drawer(props: DrawerProps): React.ReactElement;
export interface ModalProps { title: string; children: React.ReactNode; confirmLabel: string; cancelLabel?: string; destructive?: boolean; onConfirm?: () => void; onCancel?: () => void }
export declare function Modal(props: ModalProps): React.ReactElement;
export interface SearchFieldProps { placeholder?: string; shortcut?: string }
export declare function SearchField(props: SearchFieldProps): React.ReactElement;
export interface FilterBarProps { filters: { label: string; value?: string; active?: boolean }[]; onClear?: () => void }
export declare function FilterBar(props: FilterBarProps): React.ReactElement;
export interface DataTableProps { columns: { key: string; label: string; align?: 'right'; kind?: 'status' | 'confidence' | 'mono' }[]; rows: Record<string, any>[]; selectable?: boolean; caption?: string }
export declare function DataTable(props: DataTableProps): React.ReactElement;
export interface KpiTileProps { label: string; value: string; delta?: string; trend?: 'up' | 'down' | 'flat'; comparison?: string }
export declare function KpiTile(props: KpiTileProps): React.ReactElement;
export interface BarChartProps { data: { label: string; value: number; display?: string }[]; multi?: boolean; label?: string }
export declare function BarChart(props: BarChartProps): React.ReactElement;
export interface DocumentViewerProps { name: string; page?: number; pages?: number; height?: number | string; children?: React.ReactNode }
export declare function DocumentViewer(props: DocumentViewerProps): React.ReactElement;
export interface CitationProps { n: number; label?: string; active?: boolean; onClick?: () => void }
export declare function Citation(props: CitationProps): React.ReactElement;
export interface ExtractedFieldProps { label: string; value: string | null; confidence?: number | null; source?: string | null; cite?: number; required?: boolean; thresholds?: { high?: number; review?: number }; note?: string; decision?: 'accepted' | 'rejected'; active?: boolean; onHover?: () => void }
export declare function ExtractedField(props: ExtractedFieldProps): React.ReactElement;
export interface ExtractionReviewProps { documentName: string; fields: (ExtractedFieldProps & { key: string })[]; page?: number; pages?: number; model?: string; renderDocument?: (activeKey: string) => React.ReactNode }
export declare function ExtractionReview(props: ExtractionReviewProps): React.ReactElement;
export interface WorkflowStepperProps { steps: { label: string; state?: 'done' | 'current' | 'attention' | 'failed' | 'upcoming'; detail?: string }[]; label?: string }
export declare function WorkflowStepper(props: WorkflowStepperProps): React.ReactElement;
export interface StepListProps { items: { name: string; outcome: 'ok' | 'running' | 'review' | 'failed' | 'stopped' | 'skipped' | 'queued'; summary?: string; duration?: string; cost?: string }[] }
export declare function StepList(props: StepListProps): React.ReactElement;
export interface RunStatusProps { verdict: 'ran_ok' | 'running' | 'partial' | 'stopped' | 'failed'; detail?: string; metrics?: { label: string; value: string }[] }
export declare function RunStatus(props: RunStatusProps): React.ReactElement;
export interface ReviewQueueProps { items: { item: string; reason: string; confidence: number | null; status: string; age: string }[] }
export declare function ReviewQueue(props: ReviewQueueProps): React.ReactElement;
export interface ApprovalCardProps { title: string; summary?: string; children?: React.ReactNode; approveLabel?: string; rejectLabel?: string; delegate?: boolean }
export declare function ApprovalCard(props: ApprovalCardProps): React.ReactElement;
export interface AuditTrailProps { events: { actor: 'person' | 'ai' | 'system'; who: string; initials?: string; action: string; from?: string; to?: string; when: string }[] }
export declare function AuditTrail(props: AuditTrailProps): React.ReactElement;
export interface CopilotPanelProps { title?: string; context?: string; suggestions?: (string | { label: string; intent?: 'prompt' | 'action' })[]; placeholder?: string; note?: string; onClose?: () => void; children?: React.ReactNode }
export declare function CopilotPanel(props: CopilotPanelProps): React.ReactElement;
export interface ChatMessageProps { role?: 'user' | 'assistant' | 'system'; children: React.ReactNode; meta?: React.ReactNode; disclosure?: string; feedback?: boolean }
export declare function ChatMessage(props: ChatMessageProps): React.ReactElement;
export interface ThinkingIndicatorProps { children: React.ReactNode; onStop?: () => void }
export declare function ThinkingIndicator(props: ThinkingIndicatorProps): React.ReactElement;
export interface SuggestionChipsProps { items: (string | { label: string; intent?: 'prompt' | 'action' })[]; onPick?: (item: { label: string; intent?: string }) => void }
export declare function SuggestionChips(props: SuggestionChipsProps): React.ReactElement;
export interface ComposerProps { placeholder?: string }
export declare function Composer(props: ComposerProps): React.ReactElement;
export interface PlanCardProps { title: string; steps: string[]; outcome?: string; assumptions?: string[]; estimate?: string; actions?: { label: string; role: 'primary' | 'alternative' | 'cancel'; destructive?: boolean; onClick?: () => void }[] }
export declare function PlanCard(props: PlanCardProps): React.ReactElement;
export interface ConfirmCardProps { consequence: string; scope?: string; cost?: string; reversible?: 'yes' | 'no' | 'unknown'; actions: { label: string; role: 'primary' | 'alternative' | 'cancel'; destructive?: boolean; onClick?: () => void }[] }
export declare function ConfirmCard(props: ConfirmCardProps): React.ReactElement;
export interface HandoffCardProps { to: string; status: 'offered' | 'sent'; contextSent?: string[]; eta?: string; action?: { label: string; role: 'primary' | 'alternative' } }
export declare function HandoffCard(props: HandoffCardProps): React.ReactElement;
export interface SourcesProps { sources: { label: string; locator?: string; asOf?: string }[] }
export declare function Sources(props: SourcesProps): React.ReactElement;
export interface DisclosureProps { summary: string; meta?: string; icon?: string; open?: boolean; children?: React.ReactNode }
export declare function Disclosure(props: DisclosureProps): React.ReactElement;
export interface ChatHistoryProps { groups: { title: string; items: { id: string; title: string; context?: string; when: string; pinned?: boolean }[] }[]; active?: string; onSelect?: (id: string) => void; onNew?: () => void }
export declare function ChatHistory(props: ChatHistoryProps): React.ReactElement;
export interface ChatSurfaceProps { embedded?: boolean; mode?: 'collapsed' | 'panel' | 'expanded' | 'fullscreen'; onModeChange?: (m: string) => void; title?: string; context?: string; history?: ChatHistoryProps['groups']; activeConversation?: string; exitLabel?: string; launchLabel?: string; suggestions?: (string | { label: string; intent?: 'prompt' | 'action' })[]; placeholder?: string; note?: string; children?: React.ReactNode }
export declare function ChatSurface(props: ChatSurfaceProps): React.ReactElement;
export interface WorkspaceLayoutProps { center: React.ReactNode; left?: React.ReactNode; right?: React.ReactNode; leftTitle?: string; rightTitle?: string; leftIcon?: string; rightIcon?: string; leftActions?: React.ReactNode; rightActions?: React.ReactNode; leftCollapsed?: boolean; rightCollapsed?: boolean; header?: React.ReactNode; centerTitle?: string; centerActions?: React.ReactNode; height?: number | string }
export declare function WorkspaceLayout(props: WorkspaceLayoutProps): React.ReactElement;
export interface ListDetailProps { items: ({ id: string } & Record<string, any>)[]; columns: DataTableProps['columns']; renderDetail?: (item: any) => React.ReactNode; renderFooter?: (item: any) => React.ReactNode; toolbar?: React.ReactNode; overline?: string; titleKey?: string; subtitleKey?: string; defaultSelected?: string; height?: number | string }
export declare function ListDetail(props: ListDetailProps): React.ReactElement;
export interface CompareViewProps { items: { title: string; subtitle?: string; badge?: React.ReactNode }[]; rows: { label: string; values: (string | number)[]; numeric?: boolean }[]; summary?: React.ReactNode; baselineLabel?: string | false; onlyDifferences?: boolean; selectable?: boolean; selectLabel?: string }
export declare function CompareView(props: CompareViewProps): React.ReactElement;
