# Tag

Neutral, optionally removable label for categories, document types, entities and applied filters.

**Provide** `children`, optional `onRemove`.

- Tags describe things; they don't show state. For state, use `StatusBadge`.
