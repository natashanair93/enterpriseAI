# SegmentedControl

Switch between two to four views of the same content: Document / Table, Summary / Detail, Day / Week / Month.

**Provide** `options`, optional `value` + `onChange`, and a `label` for assistive tech.

- Changes the view, not the data. Use `Tabs` for separate sections and `FilterBar` for narrowing data.
