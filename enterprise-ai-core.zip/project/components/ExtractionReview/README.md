# ExtractionReview

Page pattern for human-in-the-loop extraction: the source document on the left, extracted fields on the right, linked by hover and highlight, with a summary of what was auto-accepted and a submit action.

**Provide** `documentName`, `fields` (`ExtractedField` props + `key`), optional `page`, `pages`, `model`, `renderDocument(activeKey)` to render the page with the active highlight.

- Order fields by what needs a decision: missing, then low, then medium, then auto-accepted (collapsible).
- Submit stays available. If decisions are outstanding it lists them instead of silently disabling.
- Stacks vertically below 760px, with the document first.
