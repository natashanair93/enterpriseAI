# Card

General container for an object summary: overline, title, description, a status, and footer metadata. Clickable when it leads somewhere.

**Provide** optional `overline` (object type), `title`, `description`, `status` (a `StatusBadge`), `footer`, `children`, `onClick`.

- Cards rest on a hairline border, not a shadow. On hover, interactive cards darken the border and turn the title link-colored.
- Descriptions clamp at two lines. Keep card heights uniform in a grid (`minmax(300px,1fr)`).
