# AuditTrail

Timeline of who did what, when: people, the AI, and the system, each visually distinct, with before → after values for edits.

**Provide** `events` (`{ actor: 'person' | 'ai' | 'system', who, initials?, action, from?, to?, when }[]`).

- Required wherever AI output feeds a decision. Record the original AI value, the confidence, the reviewer's change, and the timestamp.
- AI events use the `ai` color and sparkle; never present AI actions as a person's.
