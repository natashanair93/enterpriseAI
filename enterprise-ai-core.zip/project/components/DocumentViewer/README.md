# DocumentViewer

Source-document canvas with a toolbar (name, page, zoom, download) and support for highlighted regions, so every AI claim can be traced to where it came from.

**Provide** `name`, optional `page`, `pages`, `height`, and `children` (the rendered page, or your PDF renderer). Wrap cited or extracted text in `EAI.Highlight` (`active` for the one in focus).

- Highlights use `highlight` / `highlight-active`. Hovering an extracted field or citation highlights and scrolls to its region; clicking a region focuses the field.
- Show the original, never a reformatted copy, when the user needs to verify. Spatial grounding catches errors a confidence score misses.
