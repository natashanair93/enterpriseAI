# Drawer

Right-side panel for detail and edit without leaving the list: overline, title, body, sticky footer actions.

**Provide** `title`, optional `overline`, `subtitle`, `footer`, `fixed` (pin under the header), `onClose`, `children`.

- Width `panel-width`. It overlays content with `shadow-panel`, or pushes content on wide layouts.
- Opening a drawer never discards unsaved edits elsewhere. Closing one with edits asks first.
