# AppHeader

Top bar: client logo (or a lettermark plus company name), product name, optional search or actions, account avatar.

**Provide** `company`, `product`, optional `logoSrc` (from the brand layer), `initials`, `children` (header search or actions).

- The brand layer supplies the logo. Without one, the lettermark uses `accent`.
- Keep it quiet: white surface and a hairline. No colored header bars unless the client's guidelines require one.
