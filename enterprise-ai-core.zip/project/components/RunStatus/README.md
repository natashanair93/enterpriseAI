# RunStatus

One-line outcome of something that ran: verdict, a short detail when not ok, and up to five metrics.

**Provide** `verdict` (`ran_ok` | `running` | `partial` | `stopped` | `failed`), optional `detail`, `metrics` (`{ label, value }[]`).

- Only for things that ran (extractions, runs, queries, exports). Never on access, approval or handoff messages.
- "Stopped" = hit a limit or was cancelled; "Failed" = an error. A grader that errored is "couldn't grade", not a low score.
