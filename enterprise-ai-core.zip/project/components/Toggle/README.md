# Toggle

On/off switch for settings that apply immediately, like "Show only fields needing review" or "Auto-accept high confidence".

**Provide** `checked` + `onChange` (or leave uncontrolled), and `children` (visible label) or `label`.

- Takes effect at once, with no Save. Choices that need saving use `Checkbox`.
