# ApprovalCard

Human approval gate: what's being approved, a summary of what changed and what's at stake, a comment box, and Approve / Reject (optionally Reassign).

**Provide** `title`, `summary`, optional `children` (key figures, diff), `approveLabel`, `rejectLabel`, `delegate`.

- Show what the approver needs to decide on the card itself: key figures, what the AI did, what people changed, open flags. Don't make them open three tabs.
- Rejection requires a comment. Every decision goes to the `AuditTrail`.
