# ProgressBar

Determinate or indeterminate progress for uploads, batch extraction and long runs.

**Provide** `label` (verb + object: "Extracting 3 documents"), `value` (0–1, omit for indeterminate), optional `detail` ("18 of 48 pages").

- Show real progress only. If the system can't count, use indeterminate rather than a fake percentage.
