# StatusBadge

Status as icon + word in a tinted pill. One vocabulary for documents, runs, fields and approvals.

**Provide** `status`: `complete`, `approved`, `passed` (success) · `review`, `pending`, `stopped` (warning) · `failed`, `rejected` (error) · `running` (info) · `draft`, `queued`, `archived` (neutral) · `ai`. Optional `children` to override the word.

- Never color alone; the icon and word carry the meaning in every theme.
- A run that hit a limit is `stopped`, not `failed`. A field that couldn't be read is `review`, not `failed`.
- Status colors come from role tokens; a brand layer may change the shades, never the meanings.
