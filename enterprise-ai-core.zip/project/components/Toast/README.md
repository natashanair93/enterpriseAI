# Toast

Brief confirmation of what just happened, bottom-right, auto-dismissing.

**Provide** `children` (one sentence, past tense), `tone`, optional `action` (e.g. an Undo button) and `onClose`.

- "Valuation sent to Priya Shah for approval." Never "Success!".
- Keep it on screen at least 5 seconds; with an action, until dismissed.
