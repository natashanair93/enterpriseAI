# StepList

Step-by-step trace of an automated run or agent: status icon, exact step name, a summary, and duration or cost. The running step gets an info-colored edge.

**Provide** `items` (`{ name, outcome: 'ok' | 'running' | 'review' | 'failed' | 'stopped' | 'skipped' | 'queued', summary?, duration?, cost? }[]`).

- Expand anything not `ok`. Collapse long runs of passing steps behind "All 5 passing steps".
- Steps that acted on the user's behalf (sent, wrote, published) are always visible.
