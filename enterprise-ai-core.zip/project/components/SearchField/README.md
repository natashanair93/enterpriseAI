# SearchField

Search input with icon and optional keyboard-shortcut hint.

**Provide** `placeholder` (name what's searchable: "Search documents"), optional `shortcut`.

- For AI-powered search that answers questions, open the `CopilotPanel` instead of overloading this field.
