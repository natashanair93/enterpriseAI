# ChatSurface

The assistant in all four sizes, one component with the same thread and state across sizes:

- **Collapsed:** a floating "Ask AI" launcher, bottom-right.
- **Panel:** docked at `panel-width` beside the work. The default, because the user keeps their context.
- **Expanded:** wider (up to 680px) for long answers, tables or comparisons. The work stays visible.
- **Full screen:** takes over the view, with `ChatHistory` on the left and the thread centered at 760px max. For research-style work where the conversation is the task. "Back to <page>" returns to panel mode.

**Provide** `mode` (`collapsed` | `panel` | `expanded` | `fullscreen`) with `onModeChange`, or leave it uncontrolled. Also `title`, `context` (the object in scope), `history` + `activeConversation` (full screen), `exitLabel`, `suggestions`, `placeholder`, `note`, `children` (the thread).

- Switching size never resets the conversation, scroll position or draft.
- The header controls are in a fixed order: widen/narrow, full screen, close. Close collapses to the launcher; it doesn't delete the conversation.
- Answers lead; their work sits in a `Disclosure` above. Citations open the source in the main view, not inside the chat.

`embedded` hides the surface's own header and border when it sits inside a pane that already has one, such as the right pane of `WorkspaceLayout`. The pane header then carries the history and full-screen actions.
