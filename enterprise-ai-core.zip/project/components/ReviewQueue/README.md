# ReviewQueue

Exceptions inbox: items the automation couldn't finish, each with a plain-language reason, the lowest confidence, status and wait time. Selectable for bulk action.

**Provide** `items` (`{ item, reason, confidence, status, age }[]`).

- The reason column is the most important one: "Two discount rates on p. 12", not "Low confidence".
- Default sort is oldest first (SLA). Pair with `FilterBar` and a count in `SideNav`.
