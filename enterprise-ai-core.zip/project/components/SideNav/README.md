# SideNav

Left navigation for products with several areas: sections, icons, counts, and the current page marked by fill, weight and an accent bar.

**Provide** `sections` (`{ title?, items: { label, icon?, count? }[] }[]`), `active`, optional `onNavigate`, `label`.

- Up to about 8 items per section. Counts show work waiting ("Review queue 12"), not totals.
- On narrow screens the product collapses it behind a menu button.
