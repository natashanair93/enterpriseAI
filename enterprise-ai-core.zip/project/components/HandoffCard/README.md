# HandoffCard

Passes the case to a person, team or another system, saying what goes with it and when to expect a reply.

**Provide** `to`, `status` (`offered` | `sent`), optional `contextSent`, `eta`, `action`.

- The status stays "Not sent yet" until the system confirms delivery. Name a real destination; never "contact support".
