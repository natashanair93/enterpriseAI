# ExtractedField

One AI-extracted value, ready for review: label, value, confidence, source location, and accept / edit / reject.

**Provide** `label`, `value` (`null` when not found), `confidence`, `source`, optional `cite`, `required`, `thresholds`, `note`, `decision`, `active`, `onHover`.

- Routing follows the thresholds. Below `review` (default 0.70) or missing gets a red edge and must be decided. Between `review` and `high` gets an amber edge. High confidence can be auto-accepted unless the field is high-impact.
- "Not found in document" is a value state, not an error. The reviewer can enter the value or mark it not applicable.
- Every accept, edit and reject is written to the `AuditTrail` with the original value, the confidence, the reviewer and the time.
- Hovering a field highlights its source region in `DocumentViewer`.
