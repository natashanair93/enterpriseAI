# EmptyState

What a view shows when there is nothing yet, or nothing left: icon tile, title, one line, one or two actions.

**Provide** `title`, `text`, optional `icon`, `action`, `actionIcon`, `secondary`.

- Say what will appear and how to get it. Celebrate nothing: "No items need review" beats "All done! 🎉".
- No illustrations or emoji by default; a brand layer may add a client illustration.
