# TextField

Labeled text input with helper text, error state, and an AI-prefilled state.

**Provide** `label`, optional `value`, `placeholder`, `help`, `error`, `required`, `type`, `disabled`, `aiFilled` (+ `aiNote`).

- The label always sits above the field. Placeholders are examples, never instructions.
- Errors say what's wrong and how to fix it ("Enter a rate between 0% and 25%"), shown on blur or submit, not while typing.
- `aiFilled` tints the field with `ai-subtle` and adds an inline `AILabel`. Clear it as soon as the user edits.
