# Disclosure

Collapsed section behind a summary line. In chat it holds the work behind an answer (steps, tool calls, sources checked), so the answer leads and the detail is one click away. In pages it holds secondary detail.

**Provide** `summary` (states what's inside *and* the conclusion: "Checked 2 documents", "All 5 passing steps"), optional `meta` (duration, count), `icon`, `open`, `children`.

- Never "More" or "Details". Nothing the user needs to act on may live only inside.
- In chat, put the disclosure above the answer text, collapsed by default. Expand it automatically when a step failed or acted on the user's behalf.
