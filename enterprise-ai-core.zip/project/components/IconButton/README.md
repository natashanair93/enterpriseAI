# IconButton

Icon-only button for toolbars, table rows, panel headers and message actions.

**Provide** `icon` and `label` (required; it's the accessible name and tooltip), optional `size="sm"`, `pressed` for toggles, `disabled`, `onClick`.

- Only for universally understood actions (close, copy, more, zoom, accept/reject in dense review lists). Otherwise use a labeled `Button`.
