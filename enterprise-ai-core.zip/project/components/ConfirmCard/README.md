# ConfirmCard

Blocks a consequential action proposed in chat until the user decides. The consequence comes first, then scope, cost and reversibility, then a verb-labeled confirm, a safer alternative, and Cancel.

**Provide** `consequence`, optional `scope`, `cost`, `reversible` (`yes` | `no` | `unknown`), `actions`.

- For anything destructive, irreversible, shared, external, or above a cost threshold.
- The confirm label is the consequence's verb ("Overwrite 3 records"). It should never look celebratory. After the decision, say what happened in one line.
