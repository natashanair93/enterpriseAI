# Button

The button system: primary (accent fill), secondary (outlined), tertiary (text), and danger. Three sizes.

**Provide** `children`, `variant` (`primary` | `secondary` | `tertiary` | `danger`), `size` (`sm` | `md` default | `lg`), optional `icon` / `trailingIcon`, `disabled`, `onClick`.

- One primary button per view or card. Label it with the verb of the outcome: `Approve valuation`, `Run extraction`, `Export to Excel`. Never OK / Yes / Submit when a specific verb exists.
- `danger` only to confirm something destructive or irreversible, inside a `Modal` or `ConfirmCard`.
- `sm` inside tables, toolbars and chat cards; `lg` for the main action of an empty state or the composer.
- Disabled buttons must explain why nearby (helper text or tooltip). Prefer leaving the button enabled and showing a validation message on click.
