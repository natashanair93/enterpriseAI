# PlanCard

What the assistant will do before doing it: title, outcome, 3–7 checkable steps, assumptions, estimate, and actions.

**Provide** `title`, `steps`, optional `outcome`, `assumptions`, `estimate`, `actions` (`{ label, role: 'primary' | 'alternative' | 'cancel' }[]`).

- Use for work with three or more steps, anything slow, anything touching shared records, or anything that costs money. Nothing starts until the user acts.
- Unknown time or cost is written "unknown", never guessed.
