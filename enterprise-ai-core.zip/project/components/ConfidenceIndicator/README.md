# ConfidenceIndicator

Shows how sure the model is about a value, as three bars, a word (High / Review / Low) and the percentage.

**Provide** `value` (0–1, or `null` when there is no score), optional `thresholds` (`{ high: 0.9, review: 0.7 }` defaults), `level` to force a bucket, `showValue`.

- The thresholds are the workflow's, not the component's. Set them per field type, and keep high-impact fields (amounts, dates, parties) in review even when confidence is high.
- No score means review. Never show a missing score as 0% or as high.
- Confidence measures the model's certainty, not whether the source supports the value. Always pair it with the source location (`Citation` / highlight).
