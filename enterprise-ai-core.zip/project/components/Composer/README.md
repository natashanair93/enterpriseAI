# Composer

Message input: an auto-growing textarea with a send button that enables once there's text.

**Provide** `placeholder` that names the scope ("Ask about this document…").

- Enter sends and Shift+Enter adds a new line (product layer). The send button is disabled when the field is empty.
