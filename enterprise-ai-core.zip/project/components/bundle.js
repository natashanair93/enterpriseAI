/* @ds-bundle: {"format":4,"namespace":"EAI","components":[{"name":"Icon"},{"name":"AILabel"},{"name":"Button"},{"name":"IconButton"},{"name":"SegmentedControl"},{"name":"Toggle"},{"name":"TextField"},{"name":"Select"},{"name":"Checkbox"},{"name":"StatusBadge"},{"name":"Tag"},{"name":"ConfidenceIndicator"},{"name":"InlineAlert"},{"name":"Toast"},{"name":"ProgressBar"},{"name":"AppHeader"},{"name":"SideNav"},{"name":"Tabs"},{"name":"Breadcrumbs"},{"name":"Card"},{"name":"Panel"},{"name":"KeyValueList"},{"name":"EmptyState"},{"name":"Drawer"},{"name":"Modal"},{"name":"SearchField"},{"name":"FilterBar"},{"name":"DataTable"},{"name":"KpiTile"},{"name":"BarChart"},{"name":"DocumentViewer"},{"name":"Citation"},{"name":"ExtractedField"},{"name":"ExtractionReview"},{"name":"WorkflowStepper"},{"name":"StepList"},{"name":"RunStatus"},{"name":"ReviewQueue"},{"name":"ApprovalCard"},{"name":"AuditTrail"},{"name":"CopilotPanel"},{"name":"ChatMessage"},{"name":"ThinkingIndicator"},{"name":"SuggestionChips"},{"name":"Composer"},{"name":"PlanCard"},{"name":"ConfirmCard"},{"name":"HandoffCard"},{"name":"Sources"},{"name":"Disclosure"},{"name":"ChatHistory"},{"name":"ChatSurface"},{"name":"WorkspaceLayout"},{"name":"ListDetail"},{"name":"CompareView"}]} */
(function () {
  var React = window.React, h = React.createElement, useState = React.useState;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }

  var PATHS = {
    sparkle: 'M12 3l1.9 5.1L19 10l-5.1 1.9L12 17l-1.9-5.1L5 10l5.1-1.9L12 3zM19 15l.8 2.2L22 18l-2.2.8L19 21l-.8-2.2L16 18l2.2-.8L19 15z',
    file: 'M14 3H7a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2V8l-5-5zM14 3v5h5M9 13h6M9 17h4',
    database: 'M4 5c0-1.7 3.6-3 8-3s8 1.3 8 3-3.6 3-8 3-8-1.3-8-3zM4 5v6c0 1.7 3.6 3 8 3s8-1.3 8-3V5M4 11v6c0 1.7 3.6 3 8 3s8-1.3 8-3v-6',
    workflow: 'M5 3h4v4H5zM15 17h4v4h-4zM7 7v4a2 2 0 0 0 2 2h6a2 2 0 0 1 2 2v2',
    inbox: 'M3 13h5l2 3h4l2-3h5M5 5h14l2 8v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-6l2-8z',
    chart: 'M4 20V10M10 20V4M16 20v-7M22 20H2',
    home: 'M3 11l9-8 9 8v9a1 1 0 0 1-1 1h-5v-6H9v6H4a1 1 0 0 1-1-1v-9z',
    settings: 'M12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6zM19.4 15a1.7 1.7 0 0 0 .3 1.8l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.8-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.8.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.8 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.8l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.8.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.8-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.8V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z',
    user: 'M12 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM4 21a8 8 0 0 1 16 0',
    check: 'M20 6L9 17l-5-5',
    checkCircle: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8 12l3 3 5-6',
    clock: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 7v5l3 3',
    xCircle: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM15 9l-6 6M9 9l6 6',
    stopCircle: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM9 9h6v6H9z',
    dashCircle: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM8 12h8',
    info: 'M12 21a9 9 0 1 0 0-18 9 9 0 0 0 0 18zM12 8h.01M12 11v5',
    alert: 'M12 9v4m0 4h.01M10.3 3.9L1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z',
    eye: 'M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7zM12 15a3 3 0 1 0 0-6 3 3 0 0 0 0 6z',
    edit: 'M12 20h9M16.5 3.5a2.1 2.1 0 0 1 3 3L7 19l-4 1 1-4 12.5-12.5z',
    x: 'M18 6L6 18M6 6l12 12',
    search: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3',
    send: 'M5 12h14M13 6l6 6-6 6',
    arrowUp: 'M12 19V5M6 11l6-6 6 6',
    arrowDown: 'M12 5v14M6 13l6 6 6-6',
    chevronRight: 'M9 18l6-6-6-6',
    chevronDown: 'M6 9l6 6 6-6',
    chevronLeft: 'M15 18l-6-6 6-6',
    filter: 'M3 5h18l-7 8v6l-4 2v-8L3 5z',
    plus: 'M12 5v14M5 12h14',
    copy: 'M9 9h11v11H9zM5 15V5a2 2 0 0 1 2-2h10',
    thumbUp: 'M7 10v11M7 10l4-7a2 2 0 0 1 3 2l-1 5h6a2 2 0 0 1 2 2.3l-1.2 6A2 2 0 0 1 17.8 21H7',
    thumbDown: 'M17 14V3M17 14l-4 7a2 2 0 0 1-3-2l1-5H5a2 2 0 0 1-2-2.3l1.2-6A2 2 0 0 1 6.2 3H17',
    refresh: 'M21 12a9 9 0 1 1-2.6-6.4M21 3v6h-6',
    external: 'M14 4h6v6M20 4l-9 9M18 14v5a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V7a1 1 0 0 1 1-1h5',
    download: 'M12 3v12M6 11l6 6 6-6M4 21h16',
    zoomIn: 'M11 18a7 7 0 1 0 0-14 7 7 0 0 0 0 14zM21 21l-4.3-4.3M11 8v6M8 11h6',
    loader: 'M12 3a9 9 0 1 0 9 9',
    more: 'M5 12h.01M12 12h.01M19 12h.01',
    panel: 'M3 4h18v16H3zM15 4v16',
    lock: 'M6 11h12v9H6zM9 11V7a3 3 0 0 1 6 0v4',
    undo: 'M9 14L4 9l5-5M4 9h11a5 5 0 0 1 0 10h-3',
    maximize: 'M15 3h6v6M9 21H3v-6M21 3l-7 7M3 21l7-7',
    minimize: 'M4 14h6v6M20 10h-6V4M14 10l7-7M3 21l7-7',
    panelLeft: 'M3 4h18v16H3zM9 4v16',
    panelRight: 'M3 4h18v16H3zM15 4v16',
    history: 'M3 12a9 9 0 1 0 3-6.7L3 8M3 3v5h5M12 7v5l4 2',
    message: 'M21 12a8 8 0 0 1-8 8H4l2.5-2.5A8 8 0 1 1 21 12z',
    columns: 'M3 4h18v16H3zM12 4v16',
    arrowLeft: 'M19 12H5M11 6l-6 6 6 6',
    pin: 'M12 17v5M9 3h6l-1 6 4 4H6l4-4-1-6z',
    book: 'M4 5a2 2 0 0 1 2-2h14v16H6a2 2 0 0 0-2 2V5zM20 19H6a2 2 0 0 0-2 2'
  };
  function Icon(p) {
    return h('svg', { className: cx('eai-ico', p.className), viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', strokeLinecap: 'round', strokeLinejoin: 'round', role: p.label ? 'img' : undefined, 'aria-label': p.label, 'aria-hidden': p.label ? undefined : 'true', style: p.size ? { width: p.size, height: p.size } : undefined }, h('path', { d: PATHS[p.name] || PATHS.info }));
  }

  /* ---------- AI presence ---------- */
  function AILabel(p) {
    var st = useState(!!p.open);
    return h('span', { style: { position: 'relative', display: 'inline-flex' } },
      h('button', { type: 'button', className: cx('eai-ai', p.inline && 'eai-ai--inline'), 'aria-expanded': st[0], 'aria-label': 'AI-generated — explain', onClick: function () { st[1](!st[0]); } }, h(Icon, { name: 'sparkle' }), p.text || 'AI'),
      st[0] && h('div', { className: 'eai-ai-pop', role: 'dialog' }, h('h4', null, p.title || 'Generated by AI'), h('div', { className: 'eai-muted' }, p.summary || 'Review before relying on it.'),
        p.details && h('dl', null, p.details.map(function (d) { return [h('dt', { key: d.k + 't' }, d.k), h('dd', { key: d.k + 'd' }, d.v)]; }))));
  }

  /* ---------- Actions ---------- */
  function Button(p) {
    var v = p.variant || 'primary';
    return h('button', { type: p.type || 'button', className: cx('eai-btn', v !== 'primary' && 'eai-btn--' + v, p.size && 'eai-btn--' + p.size, p.className), disabled: p.disabled, onClick: p.onClick, 'aria-label': p.ariaLabel },
      p.icon && h(Icon, { name: p.icon }), p.children, p.trailingIcon && h(Icon, { name: p.trailingIcon }));
  }
  function IconButton(p) { return h('button', { type: 'button', className: cx('eai-icon-btn', p.size === 'sm' && 'eai-icon-btn--sm', p.className), 'aria-label': p.label, title: p.label, disabled: p.disabled, onClick: p.onClick, 'aria-pressed': p.pressed }, h(Icon, { name: p.icon })); }
  function SegmentedControl(p) {
    var st = useState(p.options[0]); var val = p.value != null ? p.value : st[0];
    return h('div', { className: 'eai-seg', role: 'tablist', 'aria-label': p.label }, p.options.map(function (o) {
      return h('button', { key: o, type: 'button', role: 'tab', 'aria-selected': o === val, onClick: function () { st[1](o); p.onChange && p.onChange(o); } }, o); }));
  }
  function Toggle(p) {
    var st = useState(!!p.checked); var on = p.onChange ? !!p.checked : st[0];
    var b = h('button', { type: 'button', role: 'switch', 'aria-checked': on, 'aria-label': p.children ? undefined : p.label, className: 'eai-toggle', onClick: function () { p.onChange ? p.onChange(!on) : st[1](!on); } });
    return p.children ? h('label', { className: 'eai-toggle-row' }, p.children, b) : b;
  }

  /* ---------- Forms ---------- */
  var uid = 0; function useId(prefix) { var r = React.useRef(null); if (!r.current) r.current = prefix + (++uid); return r.current; }
  function fieldWrap(p, id, control) {
    return h('div', { className: cx('eai-field', p.error && 'is-error', p.aiFilled && 'is-ai') },
      p.label && h('label', { className: 'eai-field-label', htmlFor: id }, p.label, p.required && h('span', { className: 'req', 'aria-hidden': 'true' }, '*'), p.aiFilled && h(AILabel, { inline: true, summary: p.aiNote || 'Pre-filled from the source document. Edit to override.' })),
      control,
      (p.error || p.help) && h('div', { className: 'eai-help', id: id + '-h' }, p.error && h(Icon, { name: 'alert', size: 14 }), p.error || p.help));
  }
  function TextField(p) {
    var id = useId('tf');
    return fieldWrap(p, id, h('input', { id: id, className: 'eai-input', defaultValue: p.value, placeholder: p.placeholder, type: p.type || 'text', required: p.required, 'aria-invalid': !!p.error, 'aria-describedby': (p.error || p.help) ? id + '-h' : undefined, disabled: p.disabled }));
  }
  function Select(p) {
    var id = useId('sel');
    return fieldWrap(p, id, h('select', { id: id, className: 'eai-input', defaultValue: p.value, 'aria-describedby': (p.error || p.help) ? id + '-h' : undefined }, (p.options || []).map(function (o) { return h('option', { key: o }, o); })));
  }
  function Checkbox(p) { return h('label', { className: 'eai-check' }, h('input', { type: 'checkbox', defaultChecked: p.checked, disabled: p.disabled }), p.children); }

  /* ---------- Feedback ---------- */
  var STATUS = {
    complete: ['success', 'checkCircle', 'Complete'], approved: ['success', 'checkCircle', 'Approved'], passed: ['success', 'checkCircle', 'Passed'],
    review: ['warning', 'alert', 'Needs review'], pending: ['warning', 'clock', 'Pending'], draft: ['neutral', 'edit', 'Draft'],
    failed: ['error', 'xCircle', 'Failed'], rejected: ['error', 'xCircle', 'Rejected'],
    running: ['info', 'loader', 'Running'], queued: ['neutral', 'clock', 'Queued'], stopped: ['warning', 'stopCircle', 'Stopped'], archived: ['neutral', 'dashCircle', 'Archived'],
    ai: ['ai', 'sparkle', 'AI-generated']
  };
  function StatusBadge(p) { var s = STATUS[p.status] || STATUS.queued; return h('span', { className: 'eai-badge eai-badge--' + s[0] }, h(Icon, { name: s[1] }), p.children || s[2]); }
  function Tag(p) { return h('span', { className: 'eai-tag' }, p.children, p.onRemove && h('button', { type: 'button', 'aria-label': 'Remove ' + p.children, onClick: p.onRemove }, h(Icon, { name: 'x' }))); }
  function confLevel(v, t) { t = t || {}; var hi = t.high != null ? t.high : 0.9, lo = t.review != null ? t.review : 0.7; return v == null ? 'low' : v >= hi ? 'high' : v >= lo ? 'medium' : 'low'; }
  var CONF_WORD = { high: 'High', medium: 'Review', low: 'Low' };
  function ConfidenceIndicator(p) {
    var lvl = p.level || confLevel(p.value, p.thresholds);
    return h('span', { className: 'eai-conf eai-conf--' + lvl, title: 'Model confidence' + (p.value != null ? ' ' + Math.round(p.value * 100) + '%' : ': not available') },
      h('span', { className: 'eai-conf-bars', 'aria-hidden': 'true' }, h('i'), h('i'), h('i')),
      p.value == null ? 'No score' : CONF_WORD[lvl], p.value != null && p.showValue !== false && h('span', { className: 'pct' }, Math.round(p.value * 100) + '%'));
  }
  var ALERT_ICON = { info: 'info', success: 'checkCircle', warning: 'alert', error: 'xCircle', ai: 'sparkle' };
  function InlineAlert(p) {
    var t = p.tone || 'info';
    return h('div', { className: 'eai-alert eai-alert--' + t, role: t === 'error' ? 'alert' : 'status' }, h(Icon, { name: ALERT_ICON[t] }),
      h('div', null, p.title && h('div', { className: 'eai-alert-title' }, p.title), h('div', null, p.children), p.actions && h('div', { className: 'eai-alert-actions' }, p.actions)));
  }
  function Toast(p) { var t = p.tone || 'info'; return h('div', { className: 'eai-toast eai-toast--' + t, role: 'status' }, h(Icon, { name: ALERT_ICON[t] }), h('span', null, p.children), p.action, h(IconButton, { icon: 'x', label: 'Dismiss', size: 'sm', onClick: p.onClose })); }
  function ProgressBar(p) {
    var ind = p.value == null;
    return h('div', { className: 'eai-progress' }, (p.label || !ind) && h('div', { className: 'eai-progress-head' }, h('span', null, p.label), !ind && h('span', { className: 'eai-num' }, p.detail || Math.round(p.value * 100) + '%')),
      h('div', { className: cx('eai-progress-track', ind && 'is-indeterminate'), role: 'progressbar', 'aria-valuenow': ind ? undefined : Math.round(p.value * 100), 'aria-valuemin': 0, 'aria-valuemax': 100, 'aria-label': p.label }, h('i', { style: ind ? undefined : { width: (p.value * 100) + '%' } })));
  }

  /* ---------- Navigation ---------- */
  function AppHeader(p) {
    return h('header', { className: 'eai-header' },
      h('div', { className: 'eai-brand' }, p.logoSrc ? h('img', { src: p.logoSrc, alt: p.company || '' }) : h('span', { className: 'eai-brand-mark', 'aria-hidden': 'true' }, (p.company || 'A').charAt(0)), !p.logoSrc && (p.company || 'Company')),
      p.product && h('span', { className: 'eai-header-product' }, p.product),
      h('div', { className: 'eai-header-spacer' }), p.children,
      h('span', { className: 'eai-avatar', 'aria-label': 'Account' }, p.initials || h(Icon, { name: 'user', size: 16 })));
  }
  function SideNav(p) {
    return h('nav', { className: 'eai-nav', 'aria-label': p.label || 'Primary' }, p.sections.map(function (s, i) {
      return h(React.Fragment, { key: i }, s.title && h('div', { className: 'eai-nav-section eai-overline' }, s.title), s.items.map(function (it) {
        return h('a', { key: it.label, href: '#', 'aria-current': it.label === p.active ? 'page' : undefined, onClick: function (e) { e.preventDefault(); p.onNavigate && p.onNavigate(it.label); } }, it.icon && h(Icon, { name: it.icon }), it.label, it.count != null && h('span', { className: 'count' }, it.count));
      }));
    }));
  }
  function Tabs(p) {
    var st = useState(p.tabs[0] && (p.tabs[0].label || p.tabs[0])); var act = p.active != null ? p.active : st[0];
    return h('div', { className: 'eai-tabs', role: 'tablist' }, p.tabs.map(function (t) { var l = t.label || t;
      return h('button', { key: l, type: 'button', role: 'tab', className: 'eai-tab', 'aria-selected': l === act, onClick: function () { st[1](l); p.onChange && p.onChange(l); } }, l, t.count != null && h('span', { className: 'n' }, t.count)); }));
  }
  function Breadcrumbs(p) {
    var n = p.items.length;
    return h('nav', { 'aria-label': 'Breadcrumb' }, h('ol', { className: 'eai-crumbs', style: { listStyle: 'none', margin: 0, padding: 0 } }, p.items.map(function (it, i) {
      var last = i === n - 1;
      return h('li', { key: it, style: { display: 'inline-flex', alignItems: 'center', gap: 6 } }, last ? h('span', { 'aria-current': 'page' }, it) : h('a', { href: '#' }, it), !last && h(Icon, { name: 'chevronRight' }));
    })));
  }

  /* ---------- Containers ---------- */
  function Card(p) {
    return h('article', { className: cx('eai-card', p.onClick && 'is-interactive'), onClick: p.onClick, tabIndex: p.onClick ? 0 : undefined },
      (p.overline || p.status) && h('div', { className: 'eai-card-head' }, h('span', { className: 'eai-overline' }, p.overline), p.status),
      p.title && h('h3', { className: 'eai-card-title' }, p.title), p.description && h('p', { className: 'eai-card-desc' }, p.description), p.children,
      p.footer && h('div', { className: 'eai-card-foot' }, p.footer));
  }
  function Panel(p) {
    return h('section', { className: 'eai-panel' }, (p.title || p.actions) && h('div', { className: 'eai-panel-head' }, h('h3', { className: 'eai-panel-title' }, p.icon && h(Icon, { name: p.icon }), p.title), p.actions),
      h('div', { className: 'eai-panel-body', style: p.flush ? { padding: 0 } : undefined }, p.children));
  }
  function KeyValueList(p) { return h('dl', { className: 'eai-kv' }, p.items.map(function (it) { return [h('dt', { key: it.key + 'k' }, it.key), h('dd', { key: it.key + 'v' }, it.mono ? h('code', null, it.value) : it.value)]; })); }
  function EmptyState(p) {
    return h('div', { className: 'eai-empty' }, h('div', { className: 'eai-empty-icon' }, h(Icon, { name: p.icon || 'inbox' })), h('div', { className: 'eai-empty-title' }, p.title),
      p.text && h('p', { className: 'eai-empty-text' }, p.text), (p.action || p.secondary) && h('div', { className: 'eai-row', style: { justifyContent: 'center' } }, p.action && h(Button, { icon: p.actionIcon }, p.action), p.secondary && h(Button, { variant: 'secondary' }, p.secondary)));
  }
  function Drawer(p) {
    return h('aside', { className: cx('eai-drawer', p.fixed && 'is-fixed'), 'aria-label': p.title },
      h('div', { className: 'eai-drawer-head' }, h('div', null, p.overline && h('div', { className: 'eai-overline' }, p.overline), h('h2', { className: 'eai-drawer-title' }, p.title), p.subtitle && h('div', { className: 'eai-muted', style: { fontSize: 13.5 } }, p.subtitle)), h(IconButton, { icon: 'x', label: 'Close', onClick: p.onClose })),
      h('div', { className: 'eai-drawer-body' }, p.children), p.footer && h('div', { className: 'eai-drawer-foot' }, p.footer));
  }
  function Modal(p) {
    return h('div', { className: 'eai-scrim' }, h('div', { className: 'eai-modal', role: 'dialog', 'aria-modal': 'true', 'aria-label': p.title },
      h('div', { className: 'eai-modal-head' }, h('h2', { className: 'eai-modal-title' }, p.title), h(IconButton, { icon: 'x', label: 'Close', onClick: p.onCancel })),
      h('div', { className: 'eai-modal-body' }, p.children),
      h('div', { className: 'eai-modal-foot' }, h(Button, { variant: 'secondary', onClick: p.onCancel }, p.cancelLabel || 'Cancel'), h(Button, { variant: p.destructive ? 'danger' : 'primary', onClick: p.onConfirm }, p.confirmLabel))));
  }

  /* ---------- Data ---------- */
  function SearchField(p) { return h('div', { className: 'eai-search' }, h(Icon, { name: 'search' }), h('input', { placeholder: p.placeholder || 'Search', 'aria-label': p.placeholder || 'Search' }), p.shortcut && h('kbd', null, p.shortcut)); }
  function FilterBar(p) {
    return h('div', { className: 'eai-filterbar', role: 'group', 'aria-label': 'Filters' }, p.filters.map(function (f) {
      return h('button', { key: f.label, type: 'button', className: cx('eai-filter', f.active && 'is-active'), 'aria-pressed': !!f.active }, f.value ? f.label + ':' : f.label, f.value && h('b', null, f.value), h(Icon, { name: f.active ? 'x' : 'chevronDown' }));
    }), p.onClear && h(Button, { variant: 'tertiary', size: 'sm', onClick: p.onClear }, 'Clear all'));
  }
  function DataTable(p) {
    var sel = useState({}); var s = sel[0];
    return h('div', { className: 'eai-table-wrap' }, h('table', { className: 'eai-table' }, p.caption && h('caption', { className: 'eai-sr' }, p.caption),
      h('thead', null, h('tr', null, p.selectable && h('th', { className: 'sel' }, h('span', { className: 'eai-sr' }, 'Select')), p.columns.map(function (c) { return h('th', { key: c.key, className: c.align === 'right' ? 'is-num' : undefined, scope: 'col' }, c.label); }))),
      h('tbody', null, p.rows.map(function (r, i) {
        return h('tr', { key: i, 'aria-selected': p.selectable ? !!s[i] : undefined }, p.selectable && h('td', { className: 'sel' }, h('input', { type: 'checkbox', 'aria-label': 'Select row', checked: !!s[i], onChange: function () { var n = Object.assign({}, s); n[i] = !n[i]; sel[1](n); }, style: { width: 18, height: 18, accentColor: 'var(--accent)' } })),
          p.columns.map(function (c, j) { var v = r[c.key];
            var cell = c.kind === 'status' ? h(StatusBadge, { status: v }) : c.kind === 'confidence' ? h(ConfidenceIndicator, { value: v }) : c.kind === 'mono' ? h('code', null, v) : v;
            return h('td', { key: c.key, className: cx(c.align === 'right' && 'is-num', j === 0 && 'is-strong') }, cell); }));
      }))));
  }
  function KpiTile(p) {
    var t = p.trend || 'flat';
    return h('div', { className: 'eai-kpi' }, h('div', { className: 'eai-kpi-label' }, p.label), h('div', { className: 'eai-kpi-value' }, p.value),
      p.delta && h('div', { className: 'eai-kpi-delta ' + t }, t !== 'flat' && h(Icon, { name: t === 'up' ? 'arrowUp' : 'arrowDown' }), p.delta, p.comparison && h('span', null, ' ' + p.comparison)));
  }
  function BarChart(p) {
    var max = Math.max.apply(null, p.data.map(function (d) { return d.value; }));
    return h('figure', { className: 'eai-chart', style: { margin: 0 }, 'aria-label': p.label }, p.data.map(function (d, i) {
      return h('div', { key: d.label, className: 'eai-bar-row' }, h('span', null, d.label), h('div', { className: 'eai-bar-track' }, h('i', { style: { width: (d.value / max * 100) + '%', background: 'var(--dataviz-' + (p.multi ? (i % 6) + 1 : 1) + ')' } })), h('span', { className: 'v' }, d.display || d.value));
    }));
  }

  /* ---------- Documents & extraction ---------- */
  function Citation(p) { return h('button', { type: 'button', className: cx('eai-cite', p.active && 'is-active'), 'aria-label': 'Source ' + p.n + (p.label ? ': ' + p.label : ''), title: p.label, onClick: p.onClick }, p.n); }
  function DocumentViewer(p) {
    return h('div', { className: 'eai-doc', style: p.height ? { height: p.height } : undefined },
      h('div', { className: 'eai-doc-bar' }, h(Icon, { name: 'file' }), h('span', { className: 'name' }, p.name), p.page && h('span', { className: 'eai-muted eai-num' }, 'Page ' + p.page + (p.pages ? ' of ' + p.pages : '')),
        h(IconButton, { icon: 'zoomIn', label: 'Zoom', size: 'sm' }), h(IconButton, { icon: 'download', label: 'Download', size: 'sm' })),
      h('div', { className: 'eai-doc-canvas' }, h('div', { className: 'eai-page' }, p.children)));
  }
  function Highlight(p) { return h('mark', { className: cx('eai-hl', p.active && 'is-active'), style: { color: 'inherit' } }, p.children); }
  function ExtractedField(p) {
    var st = useState(p.decision || null); var d = st[0];
    var lvl = p.value == null || p.value === '' ? 'low' : confLevel(p.confidence, p.thresholds);
    var missing = p.value == null || p.value === '';
    return h('div', { className: cx('eai-xfield', p.active && 'is-active', !d && lvl === 'medium' && 'is-review', !d && missing && 'is-missing'), onMouseEnter: p.onHover, onFocus: p.onHover, tabIndex: 0 },
      h('div', { className: 'eai-xfield-label' }, p.label, p.required && h('span', { 'aria-hidden': 'true', style: { color: 'var(--error)' } }, '*')),
      h('div', { className: cx('eai-xfield-value', missing && 'is-empty') }, missing ? 'Not found in document' : p.value),
      h('div', { className: 'eai-xfield-actions' },
        d === 'accepted' ? h(StatusBadge, { status: 'approved' }, 'Accepted') : d === 'rejected' ? h(StatusBadge, { status: 'rejected' }) : [
          h(IconButton, { key: 'a', icon: 'check', label: 'Accept', size: 'sm', onClick: function () { st[1]('accepted'); } }),
          h(IconButton, { key: 'e', icon: 'edit', label: 'Edit', size: 'sm' }),
          h(IconButton, { key: 'r', icon: 'x', label: 'Reject', size: 'sm', onClick: function () { st[1]('rejected'); } })]),
      h('div', { className: 'eai-xfield-meta' }, h(ConfidenceIndicator, { value: missing ? null : p.confidence, level: lvl, thresholds: p.thresholds }),
        p.source && h('span', null, p.cite != null && h(Citation, { n: p.cite, label: p.source }), p.source), p.note && h('span', null, p.note)));
  }
  function ExtractionReview(p) {
    var st = useState(p.fields[0] && p.fields[0].key); var act = st[0];
    var accepted = p.fields.filter(function (f) { return confLevel(f.confidence) === 'high' && f.value; }).length;
    return h('div', { className: 'eai-xreview' },
      h(DocumentViewer, { name: p.documentName, page: p.page, pages: p.pages, height: '100%' }, p.renderDocument ? p.renderDocument(act) : null),
      h('div', { className: 'eai-xreview-side' },
        h('div', { className: 'eai-xreview-head' }, h('h3', { className: 'eai-panel-title' }, 'Extracted fields ', h(AILabel, { inline: true, summary: 'Values were extracted by a model. Fields below the review threshold need a decision.', details: [{ k: 'Model', v: p.model || 'Extraction model' }, { k: 'Review below', v: '70% confidence' }] })),
          h('span', { className: 'eai-muted', style: { fontSize: 13.5 } }, accepted + ' of ' + p.fields.length + ' auto-accepted')),
        p.fields.map(function (f) { return h(ExtractedField, Object.assign({ key: f.key }, f, { active: act === f.key, onHover: function () { st[1](f.key); } })); }),
        h('div', { className: 'eai-row', style: { justifyContent: 'flex-end', marginTop: 4 } }, h(Button, { variant: 'secondary' }, 'Save draft'), h(Button, null, 'Submit for approval'))));
  }

  /* ---------- Workflow ---------- */
  var STEPPER_ICON = { done: 'check', failed: 'x', attention: 'alert' };
  function WorkflowStepper(p) {
    return h('ol', { className: 'eai-stepper', 'aria-label': p.label || 'Workflow progress' }, p.steps.map(function (s, i) {
      return h('li', { key: s.label, className: 'is-' + (s.state || 'upcoming'), 'aria-current': s.state === 'current' ? 'step' : undefined },
        h('span', { className: 'dot' }, STEPPER_ICON[s.state] ? h(Icon, { name: STEPPER_ICON[s.state] }) : i + 1), h('span', null, s.label), s.detail && h('span', { className: 'sub' }, s.detail));
    }));
  }
  var STEP_ICON = { ok: 'checkCircle', failed: 'xCircle', stopped: 'stopCircle', skipped: 'dashCircle', queued: 'clock', running: 'loader', review: 'alert' };
  function StepList(p) {
    return h('ol', { className: 'eai-steps' }, p.items.map(function (s) {
      return h('li', { key: s.name, className: cx('eai-step', 'eai-step--' + s.outcome, s.outcome === 'running' && 'is-running') }, h(Icon, { name: STEP_ICON[s.outcome] || 'clock' }),
        h('div', null, h('div', { className: 'eai-step-name' }, s.name), s.summary && h('div', { className: 'eai-step-sum' }, s.summary)),
        (s.duration || s.cost) && h('span', { className: 'eai-step-meta' }, [s.duration, s.cost].filter(Boolean).join(' · ')));
    }));
  }
  var VERDICT = { ran_ok: ['checkCircle', 'Completed'], failed: ['xCircle', 'Failed'], stopped: ['stopCircle', 'Stopped'], partial: ['alert', 'Partial'], running: ['loader', 'Running'] };
  function RunStatus(p) {
    var v = VERDICT[p.verdict] || VERDICT.ran_ok;
    return h('div', { className: 'eai-run' }, h('span', { className: 'eai-run-verdict eai-run-verdict--' + p.verdict }, h(Icon, { name: v[0], size: 16 }), v[1]), p.detail && h('span', null, p.detail),
      (p.metrics || []).map(function (m) { return h('span', { key: m.label }, m.label + ' ', h('b', null, m.value)); }));
  }
  function ReviewQueue(p) {
    return h(DataTable, { selectable: true, caption: 'Review queue', columns: [
      { key: 'item', label: 'Item' }, { key: 'reason', label: 'Why it needs you' }, { key: 'confidence', label: 'Confidence', kind: 'confidence' }, { key: 'status', label: 'Status', kind: 'status' }, { key: 'age', label: 'Waiting', align: 'right' }], rows: p.items });
  }
  function ApprovalCard(p) {
    var st = useState(null);
    return h('section', { className: 'eai-approval', 'aria-label': 'Approval' },
      h('div', { className: 'eai-approval-head' }, h('h3', { className: 'eai-panel-title' }, p.title), st[0] ? h(StatusBadge, { status: st[0] }) : h(StatusBadge, { status: 'pending' }, 'Awaiting your approval')),
      p.summary && h('p', { className: 'eai-muted', style: { fontSize: 14.5 } }, p.summary), p.children,
      !st[0] && h('textarea', { placeholder: 'Add a comment (required to reject)', 'aria-label': 'Comment' }),
      !st[0] && h('div', { className: 'eai-row' }, h(Button, { onClick: function () { st[1]('approved'); } }, p.approveLabel || 'Approve'), h(Button, { variant: 'secondary', onClick: function () { st[1]('rejected'); } }, p.rejectLabel || 'Reject'), p.delegate && h(Button, { variant: 'tertiary' }, 'Reassign')));
  }
  function AuditTrail(p) {
    return h('ol', { className: 'eai-audit', 'aria-label': 'Audit trail' }, p.events.map(function (e, i) {
      return h('li', { key: i }, h('span', { className: cx('who', e.actor === 'ai' && 'is-ai'), 'aria-hidden': 'true' }, e.actor === 'ai' ? h(Icon, { name: 'sparkle' }) : e.actor === 'system' ? h(Icon, { name: 'settings' }) : e.initials),
        h('div', null, h('div', { className: 'what' }, h('b', null, e.who), ' ' + e.action), e.from != null && h('div', { className: 'diff' }, h('s', null, e.from), h(Icon, { name: 'send', size: 12 }), h('span', null, e.to)), h('div', { className: 'when' }, e.when)));
    }));
  }

  /* ---------- Copilot ---------- */
  function ChatMessage(p) {
    var role = p.role || 'assistant';
    if (role === 'user') return h('div', { className: 'eai-msg eai-msg--user' }, p.children);
    if (role === 'system') return h('div', { className: 'eai-msg eai-msg--system' }, p.children);
    return h('div', { className: 'eai-msg eai-msg--assistant' }, h('div', { className: 'eai-msg-head' }, h(AILabel, { inline: true, summary: p.disclosure || 'AI-generated. Check important details against the sources.' }), p.meta),
      p.children, p.feedback !== false && h('div', { className: 'eai-msg-actions' }, h(IconButton, { icon: 'copy', label: 'Copy', size: 'sm' }), h(IconButton, { icon: 'thumbUp', label: 'Helpful', size: 'sm' }), h(IconButton, { icon: 'thumbDown', label: 'Not helpful', size: 'sm' }), h(IconButton, { icon: 'refresh', label: 'Regenerate', size: 'sm' })));
  }
  function ThinkingIndicator(p) { return h('div', { className: 'eai-thinking', role: 'status' }, h(Icon, { name: 'loader' }), h('span', null, p.children), p.onStop && h(Button, { variant: 'tertiary', size: 'sm', onClick: p.onStop }, 'Stop')); }
  function SuggestionChips(p) {
    return h('div', { className: 'eai-sugg' }, p.items.map(function (it) { var o = typeof it === 'string' ? { label: it } : it;
      return h('button', { key: o.label, type: 'button', className: o.intent === 'action' ? 'is-action' : undefined, onClick: function () { p.onPick && p.onPick(o); } }, o.label); }));
  }
  function Composer(p) {
    var st = useState('');
    return h('div', { className: 'eai-composer' }, h('textarea', { rows: 1, placeholder: p.placeholder || 'Ask about this document…', 'aria-label': 'Message', value: st[0], onChange: function (e) { st[1](e.target.value); } }),
      h('button', { type: 'button', className: 'send', 'aria-label': 'Send', disabled: !st[0].trim() }, h(Icon, { name: 'arrowUp', size: 16 })));
  }
  function CopilotPanel(p) {
    return h('aside', { className: 'eai-copilot', 'aria-label': p.title || 'Assistant' },
      h('div', { className: 'eai-copilot-head' }, h(Icon, { name: 'sparkle', size: 18 }), h('span', { className: 'eai-copilot-title' }, p.title || 'Assistant'), h(IconButton, { icon: 'plus', label: 'New conversation', size: 'sm' }), h(IconButton, { icon: 'x', label: 'Close panel', size: 'sm', onClick: p.onClose })),
      p.context && h('div', { className: 'eai-copilot-context' }, h(Icon, { name: 'file', size: 14 }), 'Using: ', h('b', null, p.context)),
      h('div', { className: 'eai-copilot-thread' }, p.children),
      h('div', { className: 'eai-copilot-foot' }, p.suggestions && h(SuggestionChips, { items: p.suggestions }), h(Composer, { placeholder: p.placeholder }), h('div', { className: 'eai-copilot-note' }, p.note || 'AI can make mistakes. Verify important figures against the source.')));
  }
  function partActions(actions) {
    return h('div', { className: 'eai-part-actions' }, (actions || []).map(function (a) {
      var v = a.role === 'primary' ? (a.destructive ? 'danger' : 'primary') : a.role === 'cancel' ? 'tertiary' : 'secondary';
      return h(Button, { key: a.label, size: 'sm', variant: v, onClick: a.onClick }, a.label); }));
  }
  function PlanCard(p) {
    return h('div', { className: 'eai-part', role: 'group', 'aria-label': 'Plan' }, h('div', { className: 'eai-part-head' }, h(Icon, { name: 'workflow' }), p.title),
      p.outcome && h('div', { className: 'eai-part-meta' }, p.outcome), h('ol', null, p.steps.map(function (s) { return h('li', { key: s }, s); })),
      (p.assumptions || p.estimate) && h('div', { className: 'eai-part-meta' }, [p.assumptions && 'Assumes: ' + p.assumptions.join('; '), p.estimate && 'Estimate: ' + p.estimate].filter(Boolean).join(' · ')), partActions(p.actions));
  }
  function ConfirmCard(p) {
    return h('div', { className: 'eai-part eai-part--confirm', role: 'group', 'aria-label': 'Confirmation needed' },
      h('div', { className: 'eai-part-head' }, h(Icon, { name: 'alert' }), h('span', null, p.consequence)),
      (p.scope || p.cost || p.reversible) && h('div', { className: 'eai-part-meta' }, [p.scope, p.cost && 'Cost ' + p.cost, p.reversible === 'no' ? "Can't be undone" : p.reversible === 'yes' ? 'Can be undone' : p.reversible === 'unknown' ? 'Undo not guaranteed' : null].filter(Boolean).join(' · ')), partActions(p.actions));
  }
  function HandoffCard(p) {
    var sent = p.status === 'sent';
    return h('div', { className: 'eai-part' }, h('div', { className: 'eai-part-head' }, h(Icon, { name: 'external' }), p.to, h('span', { className: cx('tail eai-handoff-status', sent && 'is-sent') }, sent ? 'Sent' : 'Not sent yet')),
      p.contextSent && h('div', null, h('div', { className: 'eai-overline' }, sent ? 'What was shared' : 'What will be shared'), h('ul', null, p.contextSent.map(function (c) { return h('li', { key: c }, c); }))),
      p.eta && h('div', { className: 'eai-part-meta' }, p.eta), p.action && partActions([p.action]));
  }
  function Sources(p) {
    return h('div', { className: 'eai-sources' }, h('div', { className: 'eai-overline' }, 'Sources'), p.sources.map(function (s, i) {
      return h('div', { key: i, className: 'eai-source' }, h(Citation, { n: i + 1, label: s.label }), h('a', { href: '#', onClick: function (e) { e.preventDefault(); } }, s.label), s.locator && h('code', null, s.locator), s.asOf && h('span', { className: 'asof' }, 'as of ' + s.asOf)); }));
  }


  /* ---------- Disclosure ---------- */
  function Disclosure(p) {
    var st = useState(!!p.open);
    return h('div', { className: cx('eai-disc', st[0] && 'is-open') },
      h('button', { type: 'button', className: 'eai-disc-sum', 'aria-expanded': st[0], onClick: function () { st[1](!st[0]); } }, h(Icon, { name: 'chevronRight', className: 'eai-disc-chev' }), p.icon && h(Icon, { name: p.icon }), h('span', null, p.summary), p.meta && h('span', { className: 'eai-disc-meta' }, p.meta)),
      st[0] && h('div', { className: 'eai-disc-body' }, p.children));
  }

  /* ---------- Chat history ---------- */
  function ChatHistory(p) {
    var st = useState(p.active); var act = p.onSelect ? p.active : st[0];
    return h('nav', { className: 'eai-history', 'aria-label': 'Conversation history' },
      h('div', { className: 'eai-history-top' }, h(Button, { variant: 'secondary', icon: 'plus', size: 'sm', onClick: p.onNew }, 'New conversation'), h(SearchField, { placeholder: 'Search conversations' })),
      h('div', { className: 'eai-history-list' }, p.groups.map(function (g) {
        return h('div', { key: g.title, className: 'eai-history-group' }, h('div', { className: 'eai-overline eai-history-gt' }, g.title), g.items.map(function (it) {
          var on = it.id === act;
          return h('button', { key: it.id, type: 'button', className: cx('eai-history-item', on && 'is-active'), 'aria-current': on ? 'true' : undefined, onClick: function () { st[1](it.id); p.onSelect && p.onSelect(it.id); } },
            h('span', { className: 'ttl' }, it.pinned && h(Icon, { name: 'pin', size: 13 }), h('span', { className: 'ttl-t' }, it.title)), it.context && h('span', { className: 'ctx' }, h(Icon, { name: 'file', size: 12 }), it.context), h('span', { className: 'when' }, it.when));
        }));
      })));
  }

  /* ---------- Chat surface: collapsed / panel / expanded / fullscreen ---------- */
  function ChatSurface(p) {
    var st = useState(p.mode || 'panel'); var mode = p.onModeChange ? p.mode : st[0];
    function set(m) { st[1](m); p.onModeChange && p.onModeChange(m); }
    if (mode === 'collapsed') return h('div', { className: 'eai-chat-launch-wrap' }, h('button', { type: 'button', className: 'eai-chat-launch', onClick: function () { set('panel'); } }, h(Icon, { name: 'sparkle' }), p.launchLabel || 'Ask AI'));
    var full = mode === 'fullscreen';
    var head = h('div', { className: 'eai-chat-head' },
      full && p.exitLabel && h(Button, { variant: 'tertiary', size: 'sm', icon: 'arrowLeft', onClick: function () { set('panel'); } }, p.exitLabel),
      !full && h(Icon, { name: 'sparkle', size: 18 }), h('span', { className: 'eai-chat-title' }, p.title || 'Assistant'),
      mode === 'panel' && h(IconButton, { icon: 'panelRight', label: 'Widen panel', size: 'sm', onClick: function () { set('expanded'); } }),
      mode === 'expanded' && h(IconButton, { icon: 'panelRight', label: 'Narrow panel', size: 'sm', pressed: true, onClick: function () { set('panel'); } }),
      h(IconButton, { icon: full ? 'minimize' : 'maximize', label: full ? 'Exit full screen' : 'Full screen', size: 'sm', onClick: function () { set(full ? 'panel' : 'fullscreen'); } }),
      h(IconButton, { icon: 'x', label: 'Close assistant', size: 'sm', onClick: function () { set('collapsed'); } }));
    var body = h('div', { className: 'eai-chat-main' },
      p.context && h('div', { className: 'eai-copilot-context' }, h(Icon, { name: 'file', size: 14 }), 'Using: ', h('b', null, p.context)),
      h('div', { className: 'eai-chat-thread' }, h('div', { className: 'eai-chat-col' }, p.children)),
      h('div', { className: 'eai-chat-foot' }, h('div', { className: 'eai-chat-col' }, p.suggestions && h(SuggestionChips, { items: p.suggestions }), h(Composer, { placeholder: p.placeholder }), h('div', { className: 'eai-copilot-note' }, p.note || 'AI can make mistakes. Verify important figures against the source.'))));
    return h('section', { className: cx('eai-chat eai-chat--' + mode, p.embedded && 'is-embedded'), 'aria-label': p.title || 'Assistant' }, p.embedded && !full ? null : head,
      full ? h('div', { className: 'eai-chat-full' }, p.history && h(ChatHistory, { groups: p.history, active: p.activeConversation }), body) : body);
  }

  /* ---------- Three-pane workspace ---------- */
  function Pane(p) {
    var side = p.side;
    if (p.collapsed) return h('aside', { className: 'eai-pane eai-pane--' + side + ' is-collapsed', 'aria-label': p.title },
      h(IconButton, { icon: side === 'left' ? 'panelLeft' : 'panelRight', label: 'Show ' + p.title, onClick: p.onToggle }), p.icon && h('span', { className: 'eai-pane-rail-icon', title: p.title }, h(Icon, { name: p.icon })), h('span', { className: 'eai-pane-rail-label' }, p.title));
    return h('aside', { className: 'eai-pane eai-pane--' + side, 'aria-label': p.title },
      h('div', { className: 'eai-pane-head' }, p.icon && h(Icon, { name: p.icon }), h('span', { className: 'eai-pane-title' }, p.title), p.actions, h(IconButton, { icon: side === 'left' ? 'panelLeft' : 'panelRight', label: 'Hide ' + p.title, size: 'sm', onClick: p.onToggle })),
      h('div', { className: 'eai-pane-body' }, p.children));
  }
  function WorkspaceLayout(p) {
    var narrow = typeof window !== 'undefined' && window.innerWidth < 1100;
    var l = useState(p.leftCollapsed != null ? !!p.leftCollapsed : narrow), r = useState(p.rightCollapsed != null ? !!p.rightCollapsed : narrow);
    return h('div', { className: cx('eai-ws', l[0] && 'l-col', r[0] && 'r-col', !p.right && 'no-right', !p.left && 'no-left'), style: p.height ? { height: p.height } : undefined },
      p.header && h('div', { className: 'eai-ws-header' }, p.header),
      p.left && h(Pane, { side: 'left', title: p.leftTitle || 'Sources', icon: p.leftIcon || 'book', actions: p.leftActions, collapsed: l[0], onToggle: function () { l[1](!l[0]); } }, p.left),
      h('main', { className: 'eai-ws-center' }, p.centerTitle && h('div', { className: 'eai-pane-head' }, h('span', { className: 'eai-pane-title' }, p.centerTitle), p.centerActions), h('div', { className: 'eai-ws-center-body' }, p.center)),
      p.right && h(Pane, { side: 'right', title: p.rightTitle || 'Assistant', icon: p.rightIcon || 'sparkle', actions: p.rightActions, collapsed: r[0], onToggle: function () { r[1](!r[0]); } }, p.right));
  }

  /* ---------- List + detail flyout ---------- */
  function ListDetail(p) {
    var st = useState(p.defaultSelected != null ? p.defaultSelected : null); var sel = st[0];
    var items = p.items, idx = sel == null ? -1 : items.findIndex(function (it) { return it.id === sel; }), cur = items[idx];
    React.useEffect(function () { function k(e) { if (e.key === 'Escape') st[1](null); } window.addEventListener('keydown', k); return function () { window.removeEventListener('keydown', k); }; }, []);
    return h('div', { className: cx('eai-ld', cur && 'has-detail'), style: p.height ? { height: p.height } : undefined },
      h('div', { className: 'eai-ld-list' }, p.toolbar && h('div', { className: 'eai-ld-toolbar' }, p.toolbar),
        h('div', { className: 'eai-table-wrap eai-ld-table' }, h('table', { className: 'eai-table' }, h('thead', null, h('tr', null, p.columns.map(function (c) { return h('th', { key: c.key, className: c.align === 'right' ? 'is-num' : undefined }, c.label); }))),
          h('tbody', null, items.map(function (r) {
            return h('tr', { key: r.id, 'aria-selected': r.id === sel, tabIndex: 0, className: 'is-clickable', onClick: function () { st[1](r.id); }, onKeyDown: function (e) { if (e.key === 'Enter') st[1](r.id); } }, p.columns.map(function (c, j) { var v = r[c.key];
              var cell = c.kind === 'status' ? h(StatusBadge, { status: v }) : c.kind === 'confidence' ? h(ConfidenceIndicator, { value: v }) : c.kind === 'mono' ? h('code', null, v) : v;
              return h('td', { key: c.key, className: cx(c.align === 'right' && 'is-num', j === 0 && 'is-strong') }, cell); }));
          }))))),
      cur && h('aside', { className: 'eai-flyout', 'aria-label': 'Details' },
        h('div', { className: 'eai-drawer-head' }, h('div', null, p.overline && h('div', { className: 'eai-overline' }, p.overline), h('h2', { className: 'eai-drawer-title' }, cur[p.titleKey || p.columns[0].key]), p.subtitleKey && h('div', { className: 'eai-muted', style: { fontSize: 13.5 } }, cur[p.subtitleKey])),
          h(IconButton, { icon: 'chevronLeft', label: 'Previous', size: 'sm', disabled: idx <= 0, onClick: function () { st[1](items[idx - 1].id); } }), h(IconButton, { icon: 'chevronRight', label: 'Next', size: 'sm', disabled: idx >= items.length - 1, onClick: function () { st[1](items[idx + 1].id); } }),
          h(IconButton, { icon: 'maximize', label: 'Open full page', size: 'sm' }), h(IconButton, { icon: 'x', label: 'Close details', size: 'sm', onClick: function () { st[1](null); } })),
        h('div', { className: 'eai-drawer-body' }, p.renderDetail ? p.renderDetail(cur) : null), p.renderFooter && h('div', { className: 'eai-drawer-foot' }, p.renderFooter(cur))));
  }

  /* ---------- Side-by-side comparison ---------- */
  function parseNum(v) { if (typeof v === 'number') return v; if (typeof v !== 'string') return null; var m = v.replace(/[,\s]/g, '').match(/-?\d+(\.\d+)?/); return m ? parseFloat(m[0]) : null; }
  function CompareView(p) {
    var only = useState(!!p.onlyDifferences), pick = useState(null);
    var rows = p.rows.map(function (r) { var vs = r.values.map(String); var diff = vs.some(function (v) { return v !== vs[0]; }); return Object.assign({ diff: diff }, r); });
    var shown = only[0] ? rows.filter(function (r) { return r.diff; }) : rows;
    var nDiff = rows.filter(function (r) { return r.diff; }).length;
    var cols = p.items.length;
    return h('div', { className: 'eai-compare' },
      h('div', { className: 'eai-compare-bar' }, h('span', { className: 'eai-muted' }, nDiff + ' of ' + rows.length + ' fields differ'), h('span', { style: { flex: 1 } }), h(Toggle, { checked: only[0], onChange: function (v) { only[1](v); } }, 'Only differences')),
      p.summary && h(InlineAlert, { tone: 'ai', title: 'What changed' }, p.summary),
      h('div', { className: 'eai-compare-scroll' }, h('table', { className: 'eai-compare-table', style: { '--cols': cols } },
        h('thead', null, h('tr', null, h('th', { className: 'lbl', scope: 'col' }, h('span', { className: 'eai-sr' }, 'Field')), p.items.map(function (it, i) {
          return h('th', { key: i, scope: 'col', className: cx(pick[0] === i && 'is-picked') }, h('div', { className: 'eai-compare-head' }, i === 0 && p.baselineLabel !== false && h('span', { className: 'eai-overline' }, p.baselineLabel || 'Baseline'), h('div', { className: 'ttl' }, it.title), it.subtitle && h('div', { className: 'eai-muted', style: { fontSize: 13, fontWeight: 400 } }, it.subtitle), it.badge,
            p.selectable && h(Button, { size: 'sm', variant: pick[0] === i ? 'primary' : 'secondary', icon: pick[0] === i ? 'check' : undefined, onClick: function () { pick[1](i); } }, pick[0] === i ? 'Selected' : (p.selectLabel || 'Use this'))));
        }))),
        h('tbody', null, shown.map(function (r) {
          var base = parseNum(r.values[0]);
          return h('tr', { key: r.label, className: r.diff ? 'is-diff' : undefined }, h('th', { scope: 'row', className: 'lbl' }, r.diff && h('span', { className: 'eai-compare-mark', 'aria-label': 'Differs' }), r.label),
            r.values.map(function (v, i) {
              var n = parseNum(v), delta = null;
              if (r.numeric && i > 0 && base != null && n != null && base !== 0 && n !== base) { var pct = (n - base) / Math.abs(base) * 100; delta = (pct > 0 ? '+' : '') + pct.toFixed(1) + '%'; }
              var changed = i > 0 && String(v) !== String(r.values[0]);
              return h('td', { key: i, className: cx(changed && 'is-changed', pick[0] === i && 'is-picked') }, h('span', { className: r.numeric ? 'eai-num' : undefined }, v), delta && h('span', { className: 'eai-compare-delta' }, delta));
            }));
        })))));
  }

  window.EAI = Object.assign(window.EAI || {}, {
    Icon: Icon, AILabel: AILabel, Button: Button, IconButton: IconButton, SegmentedControl: SegmentedControl, Toggle: Toggle,
    TextField: TextField, Select: Select, Checkbox: Checkbox, StatusBadge: StatusBadge, Tag: Tag, ConfidenceIndicator: ConfidenceIndicator,
    InlineAlert: InlineAlert, Toast: Toast, ProgressBar: ProgressBar, AppHeader: AppHeader, SideNav: SideNav, Tabs: Tabs, Breadcrumbs: Breadcrumbs,
    Card: Card, Panel: Panel, KeyValueList: KeyValueList, EmptyState: EmptyState, Drawer: Drawer, Modal: Modal,
    SearchField: SearchField, FilterBar: FilterBar, DataTable: DataTable, KpiTile: KpiTile, BarChart: BarChart,
    DocumentViewer: DocumentViewer, Highlight: Highlight, Citation: Citation, ExtractedField: ExtractedField, ExtractionReview: ExtractionReview,
    WorkflowStepper: WorkflowStepper, StepList: StepList, RunStatus: RunStatus, ReviewQueue: ReviewQueue, ApprovalCard: ApprovalCard, AuditTrail: AuditTrail,
    CopilotPanel: CopilotPanel, ChatMessage: ChatMessage, ThinkingIndicator: ThinkingIndicator, SuggestionChips: SuggestionChips, Composer: Composer,
    PlanCard: PlanCard, ConfirmCard: ConfirmCard, HandoffCard: HandoffCard, Sources: Sources,
    Disclosure: Disclosure, ChatHistory: ChatHistory, ChatSurface: ChatSurface, WorkspaceLayout: WorkspaceLayout, ListDetail: ListDetail, CompareView: CompareView
  });
})();
