# SuggestionChips

One to three next steps under a reply, or starter prompts in an empty assistant.

**Provide** `items` (strings or `{ label, intent: 'prompt' | 'action' }`), `onPick`.

- Verb-first, under ~32 characters, something the user could have typed. Never a question to the user.
- `intent: 'action'` (Retry from page 31, Request access) is link-colored, persists, and appears on error replies.
