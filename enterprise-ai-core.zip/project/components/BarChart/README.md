# BarChart

Simple horizontal bar chart for ranked comparisons, using the data-viz tokens.

**Provide** `data` (`{ label, value, display? }[]`), optional `multi` (one color per bar), `label` (accessible description).

- One series is `dataviz-1` only. Use `multi` only when the bars are different categories that the legend or other charts refer to by color.
- Label values directly; avoid gridlines. Product layers can bring a full chart library but must use the `dataviz-*` tokens in order.
