# ChatHistory

Conversation history: New conversation, search, and past conversations grouped by recency (Today, Previous 7 days, Older), each with its title, the object it was about, and a time. Pinned conversations show a pin.

**Provide** `groups` (`{ title, items: { id, title, context?, when, pinned? }[] }[]`), `active`, optional `onSelect`, `onNew`.

- Shown as the left rail of full-screen chat. In panel mode it opens from the history button, not inline.
- Titles are generated from the first question and editable. Show the context object so people can find "the chat about the Contoso term sheet".
- Conversations scoped to a record also appear on that record ("2 conversations about this document").
