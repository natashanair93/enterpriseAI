# Patterns and layouts

The system has four levels, and each one is built from the level below:

| Level | What it is | Examples here |
|---|---|---|
| **Foundations** | Tokens: color roles, type, space, size, radius | `accent`, `heading-2`, `space-24`, `panel-width` |
| **Components** | One reusable piece of UI | `Button`, `DataTable`, `ExtractedField`, `ChatMessage` |
| **Patterns** | Components combined with behavior rules, solving one recurring problem | `ChatSurface`, `CompareView`, `Disclosure`, `ExtractionReview`, `ApprovalCard` |
| **Layouts** | Whole-screen arrangements that patterns live in | `WorkspaceLayout`, `ListDetail`, the app shell |

A brand layer changes only the foundations. Patterns and layouts are where most of the product thinking lives, so they're defined once here and reused across every client.

## Choosing a layout

| The user's job | Layout | Why |
|---|---|---|
| Work through many items: review, triage, approve | **`ListDetail`** (list + right flyout) | Keeps the queue, filters and position; detail is one click away and Esc returns |
| Work deeply on one thing with sources and an assistant | **`WorkspaceLayout`** (left sources / center work / right assistant or insights) | Inputs, work and help are visible together; side panes collapse when focus is needed |
| Verify AI output against a document | **`ExtractionReview`** (document left, fields right) | Every value sits next to where it came from |
| Choose between versions, periods, scenarios or vendors | **`CompareView`** | Aligned rows make differences visible; the AI summary explains them |
| Research or explore where the conversation is the work | **`ChatSurface`, full screen** | History on the left, a readable centered thread |
| Monitor | App shell with `KpiTile` row and `Panel`s | Scan first, drill in through `ListDetail` |

## The right side of the screen

One right-side slot, used for one thing at a time:

1. **Detail flyout** (`ListDetail`): details of the item clicked. It opens on selection and closes with Esc.
2. **Assistant** (`ChatSurface`, panel mode): scoped to what's in the center ("Using: …").
3. **Insights / activity:** AI insights, `AuditTrail`, comments, in a `WorkspaceLayout` right pane.

If a flyout and the assistant both need the right side, the flyout wins while it is open, and the assistant waits as a rail or launcher. Never stack two right panels.

## Chat: sizes and states

- **Collapsed → panel → expanded → full screen** is one continuum of the same conversation (`ChatSurface`). Default to panel, so the user keeps their work in view.
- **History** lives in `ChatHistory`: the left rail in full screen, a menu in panel mode. Conversations remember the object they were about.
- **Expanding content inside chat:** the work behind an answer goes in a `Disclosure` ("Checked 2 documents · 6s") above the answer. Long outputs (tables, comparisons, drafts) get an "Open in main view" action rather than growing the panel.
- **Inline AI entry points** (an "Explain" on a field, "Summarize" on a document) open their answer in the same panel, with the object attached as context.

## Responsive rules

- ≥ 1280px: three panes side by side.
- 1100–1280px: the right pane narrows to `panel-width`; the left pane may collapse to a rail.
- 760–1100px: side panes become rails and open as overlays with `shadow-panel`.
- < 760px: one pane at a time behind tabs or a menu; flyouts and chat become full-screen sheets.
