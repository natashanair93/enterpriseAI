# Applying a brand layer

Each client gets its own copy of this system with their brand applied. The core stays untouched. A brand layer changes only the slots below. If a client's guideline would change anything else, record it as an exception in that client's README.

## What a brand layer sets

| Slot | Tokens | From the client's guidelines | Rules |
|---|---|---|---|
| Brand color | `brand-50` … `brand-900` | Primary brand color → `brand-600`; build the tints and shades around it | `brand-600` and `brand-700` ≥ 4.5:1 on white with white text ≥ 4.5:1 on them; if the brand color is too light (yellow, lime, cyan), keep it for `brand-500` and decorative use, and darken `brand-600` until it passes |
| Neutrals | `gray-0` … `gray-900` | Warm or cool grays if specified | Keep each step's contrast: `gray-500` ≥ 4.5:1 on `gray-50`; `gray-400` ≥ 3:1 on white |
| Status hues | `green-*`, `amber-*`, `red-*`, `blue-*` | Brand-approved semantic colors, if any | Meanings never move. Success stays green-family, error red/orange-family. Each `-600`/`-700` ≥ 4.5:1 on its `-50` |
| AI hue | `violet-*` | A client "AI" color, if one exists | Must differ from `brand-600` and from all status hues |
| Data viz | `teal-600`, `magenta-600`, plus the roles above | Brand chart palette | Six distinguishable series; adjacent series differ in lightness |
| Typography | `type.families.display`, `ui`, `mono` | Brand typefaces (add the font files under `fonts/` if self-hosted) | Keep the type scale. If the brand face runs large or small, adjust sizes ±1px at most. Body text never below 13.5px |
| Shape | `radius-sm`, `radius-md`, `radius-lg` | Sharp or rounded brand | Keep sm ≤ md ≤ lg; `radius-full` stays |
| Logo | an asset group `Logos` | Logo files (SVG preferred), light and dark versions | Used only in `AppHeader` and the cover; never redrawn |
| Voice | the client README's *Content fundamentals* | Brand tone of voice | Additive only: the core rules on honesty, AI disclosure and verbs still apply |

Roles (`accent`, `surface`, `success`…) are only remapped when a client needs a structurally different look, for example `accent` → `brand-800` for a very light brand. Note every remap in the client README.

## Process

1. **Collect:** brand guidelines (PDF, site or Figma), logo files and font names or files.
2. **Copy** this system into a new design system named "<Client> AI", so the core stays clean.
3. **Map** the guideline values into the slots above. Use exact values from the guidelines and never approximate a logo or color.
4. **Check contrast** in both `neutral` and `high-contrast` themes. Where a brand color fails a role, keep the brand value in its primitive, darken the role mapping, and note it.
5. **Re-make the cover** with the client's palette, and add a client section to the README: brand colors, typefaces, logo usage, voice, exceptions.
6. **Build products** from the client system. Product code uses roles and components only, so a later brand refresh is a token change.

## In code

The compiled `tokens.css` declares every token as a CSS custom property on `:root` (and `[data-theme="high-contrast"]`). A brand layer can also ship as a plain CSS override loaded after the core:

```css
:root {
  --brand-600: #0b5cad; /* client primary */
  --brand-700: #084a8c;
  --font-display: "Client Serif", Georgia, serif;
  --radius-md: 4px;
}
```

Never override role or component styles in product code. If something can't be expressed with the slots above, propose a new token in the core.
