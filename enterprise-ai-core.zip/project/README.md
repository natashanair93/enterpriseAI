A brand-agnostic foundation for enterprise AI products: tools that read documents, extract data, run workflows, route exceptions to people, and answer questions with sources. Valuation review, contract intake, claims, KYC and reporting are all the same shape. This core supplies the structure, behavior and accessibility. A client **brand layer** supplies the look (see *Applying a brand layer*).

The voice of the interface is **clear, accountable, and calm**. The product should feel like a trustworthy colleague's work: easy to check and easy to overrule.

## How this system is built

- **Three layers.** *Primitives* (`gray-*`, `brand-*`, `green-*`…) hold raw values. *Roles* (`accent`, `surface`, `text-secondary`, `success`, `ai`…) say what a color is for. *Components* use roles only, never primitives or hex values.
- **Brand layers replace primitives, fonts and radii.** Roles and components stay untouched, so every product re-skins at once.
- **Themes:** `neutral` (default) and `high-contrast` (AAA text, 3:1 borders, color-blind-safe status). A brand layer maps into both.
- **What never changes with a brand:** status meanings, the type hierarchy, spacing, sizes, contrast floors, and the AI-presence pattern.

## Principles for enterprise AI

1. **Show the source.** Every AI-produced value or claim links to where it came from: `Citation`, highlight in `DocumentViewer`, or `Sources`. If there's no source, say so.
2. **Make AI visible, not decorative.** Mark AI output with `AILabel` and the `ai` color. Remove the mark once a person edits the value. Never use the sparkle or `ai` color as ornament.
3. **People decide, AI prepares.** Low-confidence and high-impact values route to a human (`ExtractedField`, `ReviewQueue`, `ApprovalCard`). Actions with side effects need a `PlanCard` or `ConfirmCard` first.
4. **Confidence is a routing signal, not a verdict.** Show it with `ConfidenceIndicator`, always next to the source location. A missing score means review.
5. **Everything is traceable.** Every AI action and human decision goes to the `AuditTrail` with before/after values.
6. **Honest states.** *Stopped* ≠ *failed*; *not found* ≠ *error*; *offered* ≠ *sent*; *couldn't grade* ≠ *low score*.

## Content fundamentals

- **Sentence case** for everything: headings, buttons, tabs, labels. Uppercase only in the `overline` style.
- **Address the user as "you".** The assistant speaks as "I" only inside the copilot. Never present the AI as a person or teammate, and no emotional language.
- **Lead with the outcome.** "6 fields need your review", then why. Errors say what failed, why, and what to do next.
- **Buttons use the verb of the result:** `Approve valuation`, `Run extraction`, `Overwrite 3 records`. Never OK / Yes / Submit when a specific verb exists.
- **Numbers are exact, with units and as-of times:** `$1,420.6m`, `as of 30 Sep 2026`. Tabular figures in tables and KPIs.
- **Progress names the real step:** "Reading page 12 of `Valuation_Report_Q3.pdf`", never "Thinking…".
- **No emoji, no exclamation marks, no greetings** in product copy or assistant replies.

## Visual foundations

### Color

- `accent` is the one action color: primary buttons, selected states, the active tab, the user's chat bubble. One accent per view; never add a second brand hue.
- Text: `text-primary` for content, `text-secondary` for descriptions and labels, `text-tertiary` for timestamps and overlines (still 5:1, the lowest text tier). Links use `text-link`.
- Surfaces: `surface-page` behind content, `surface` for cards and panels, `surface-sunken` for wells (document canvas, code), `surface-selected` for selection.
- Status uses roles only, always with an icon and word: `success` complete / approved, `warning` needs review / pending / stopped, `error` failed / rejected, `info` running, neutral for draft / queued. The `-subtle` partner is the fill.
- AI presence: `ai` + `ai-subtle`. Source highlights: `highlight`, and `highlight-active` for the one in focus. Confidence: `confidence-high / -medium / -low`, which alias the status roles.
- Charts: `dataviz-1` alone for one series; `dataviz-1…6` in order for several. Label values directly; keep gridlines in `border`.
- Borders: `border` for hairlines, `border-strong` for emphasis, `border-control` (3:1) for form controls.

### Type

- Three slots a brand layer fills: `display` (headings, metrics, product name), `ui` (everything else), `mono` (IDs, formulas, JSON). The default is Public Sans + JetBrains Mono.
- Hierarchy: `display` 40 · `heading-1` 28 · `heading-2` 22 · `heading-3` 18 · `heading-4` 16 · `body-lg` 16 · `body` 15 · `body-sm` 13.5 · `label` 14/600 · `overline` 12/600 caps · `caption` 12.5. Data: `metric` 28 and `data` 14, both tabular.
- One `heading-1` per page. Don't skip levels. Body text never goes below 13.5px.

### Space, size, shape, depth

- 4px base: `space-4`, `space-8`, `space-12`, `space-16`, `space-20`, `space-24`, `space-32`, `space-48`, `space-64`. Card padding `space-24`, grid gap `space-20`, page gutter `space-32` (`space-16` on phones).
- Sizes are comfortable by default: `control-md` 40px, `row-height` 52px, `header-height` 56px, `panel-width` 420px. A data-heavy project may lower `row-height` in its own layer (never below 40px). Touch targets stay ≥ 32px.
- Radius: `radius-sm` badges and highlights, `radius-md` buttons and inputs, `radius-lg` cards, panels and modals, `radius-full` pills. Brands may make these sharper or softer.
- **Borders before shadows.** Resting cards use `border`. `shadow-overlay` is only for things that float (menus, modals, toasts); `shadow-panel` is for drawers and the copilot when they overlay.

### States, motion, accessibility

- Hover: `surface-hover`, or a darker border. Selected: `surface-selected` plus `accent-text`. Disabled: `text-disabled` on `surface-hover`, always with a reason nearby.
- Focus: 2px `focus-ring` outline, offset 2px, on every interactive element, ≥ 3:1 on every surface.
- Motion: 150–240ms ease-out on color, border and slide-ins. No bounce. All motion is off under `prefers-reduced-motion`.
- WCAG 2.2 AA in `neutral`; AAA text in `high-contrast`. Every status, confidence level and chart series is distinguishable without color.

### Layout patterns

See *Patterns and layouts* for when to use each one.

- **App shell:** `AppHeader` + optional `SideNav` + content (max `content-max`) + an optional right slot (detail flyout, assistant or insights) at `panel-width`.
- **List → detail flyout:** `ListDetail`. Clicking a row opens its details in a right flyout without leaving the list; a full page with `Breadcrumbs` and `Tabs` only when the detail needs it.
- **Three-pane workspace:** `WorkspaceLayout`, with sources on the left, work in the center, and assistant or insights on the right. Side panes collapse to rails.
- **Compare:** `CompareView`, with versions, periods or scenarios side by side and differences marked.
- **Review:** `ExtractionReview`, with the document on the left and fields on the right, plus `WorkflowStepper` above it showing where the item is.
- **Decide:** `ApprovalCard` with key figures, the `AuditTrail` beside or below.
- **Monitor:** `KpiTile` row, then `BarChart` / tables in `Panel`s.

## Copilot and chat responses

- The assistant is one `ChatSurface` in four sizes: collapsed launcher, docked panel (default), expanded, and full screen with `ChatHistory`. It's scoped to the current object ("Using: …"), and changing size never resets the conversation. `CopilotPanel` is the simple fixed-panel version. Inline AI actions (summarize, explain a field) open their answers in the same surface rather than in pop-ups.
- The work behind an answer sits in a `Disclosure` above it, collapsed unless something failed or acted on the user's behalf.
- Replies are built from parts: text with `Citation`s, then `Sources`; `PlanCard` before multi-step or costly work; `ConfirmCard` before anything destructive, shared or irreversible; `HandoffCard` to pass to a person; `RunStatus` / `StepList` only for things that ran; `SuggestionChips` (1–3) for next steps.
- `ThinkingIndicator` names the real step. Feedback is neutral thumbs, never asked for in prose.

## Iconography

- Outline icons on a 24px grid with 1.75px stroke, drawn at 16–20px in `currentColor` (Lucide / Feather style). The `Icon` component carries the set.
- Icons take the color of their text. Only status icons use status roles, and only the AI sparkle uses `ai`.
- `sparkle` means AI and nothing else. No emoji, no filled or duotone icons.
- A brand layer may substitute the client's icon library if it is outline-style and keeps the names.
- There are no logo assets in the core. `AppHeader` takes the client's logo from the brand layer and falls back to a lettermark in `accent`.
